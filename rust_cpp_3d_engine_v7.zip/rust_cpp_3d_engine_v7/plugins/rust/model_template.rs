#![allow(non_snake_case)]
use std::{ptr, sync::Mutex};

const HS_MAGIC: u64 = 0x484D;
const HS_VERSION: u8 = 2;
const LANG_RUST: u8 = 1;
const PROFILE_64: u8 = 1;
const PROFILE_128: u8 = 2;
const BRIDGE_GROUP: u32 = 1;

#[derive(Default)]
struct PluginState { slot: u32, initialized: bool, profile: u8 }
static STATE: Mutex<PluginState> = Mutex::new(PluginState { slot: 0, initialized: false, profile: PROFILE_128 });

#[no_mangle]
pub extern "C" fn rust_model_handshake(hello: u64, response: *mut u64) -> i32 {
    if response.is_null() || (hello & 0xFFFF) != HS_MAGIC { return -1; }
    let version = ((hello >> 16) & 0xFF) as u8;
    let language = ((hello >> 24) & 0x3) as u8;
    let slot = ((hello >> 28) & 0xFF) as u8;
    if version != HS_VERSION || language != LANG_RUST || slot >= 10 { return -2; }
    let profile = if slot % 2 == 0 { PROFILE_64 } else { PROFILE_128 };
    let Ok(mut state) = STATE.lock() else { return -3; };
    state.slot = slot as u32;
    state.profile = profile;
    let mut word0 = HS_MAGIC;
    word0 |= (HS_VERSION as u64) << 16;
    word0 |= (LANG_RUST as u64) << 32;
    word0 |= (profile as u64) << 34;
    word0 |= (slot as u64) << 36;
    let size = if profile == PROFILE_64 { 8u64 } else { 16u64 };
    word0 |= size << 44;
    word0 |= size << 52;
    word0 |= 0xFu64 << 60;
    unsafe {
        *response = word0;
        *response.add(1) = (BRIDGE_GROUP as u64) | (((slot as u64) + 1) << 32);
    }
    0
}

#[no_mangle]
pub extern "C" fn rust_model_protocol_version() -> u32 { 2 }
#[no_mangle]
pub extern "C" fn rust_model_init(slot: u32) -> i32 {
    if slot >= 10 { return -1; }
    let Ok(mut state) = STATE.lock() else { return -2; };
    state.slot = slot; state.initialized = true; 0
}
#[no_mangle]
pub extern "C" fn rust_model_health() -> i32 {
    STATE.lock().map(|s| if s.initialized { 1 } else { 0 }).unwrap_or(0)
}

#[no_mangle]
pub unsafe extern "C" fn rust_model_exchange(input: *const u8, input_size: u32,
        output: *mut u8, output_capacity: u32, output_size: *mut u32) -> i32 {
    if input.is_null() || output.is_null() || output_size.is_null() { return -1; }
    let Ok(state) = STATE.lock() else { return -2; };
    if !state.initialized { return -3; }
    let expected = if state.profile == PROFILE_64 { 8usize } else { 16usize };
    if input_size as usize != expected || output_capacity as usize < expected { return -4; }
    ptr::copy_nonoverlapping(input, output, expected);
    if state.profile == PROFILE_64 {
        let mut word = ptr::read_unaligned(output as *const u64);
        word = (word & 0x00FF_FFFF_FFFF_FFFF) | ((state.slot as u64 & 0xFF) << 56);
        ptr::write_unaligned(output as *mut u64, word);
    } else {
        let mut word0 = ptr::read_unaligned(output as *const u64);
        let word1_ptr = output.add(8) as *mut u64;
        let mut word1 = ptr::read_unaligned(word1_ptr);
        word0 = (word0 & 0x0000_FFFF_FFFF_FFFF) | ((state.slot as u64 & 0xFF) << 48);
        word1 ^= (state.slot as u64) << 32;
        ptr::write_unaligned(output as *mut u64, word0);
        ptr::write_unaligned(word1_ptr, word1);
    }
    *output_size = expected as u32;
    0
}
#[no_mangle]
pub extern "C" fn rust_model_shutdown() {
    if let Ok(mut state) = STATE.lock() { state.initialized = false; }
}
