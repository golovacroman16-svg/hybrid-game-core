#include "../../cpp/module_protocol.h"
#include <cstdio>
#include <cstring>

namespace { std::uint32_t g_slot = 0; bool g_initialized = false; std::uint8_t g_profile = ENGINE_PROFILE_128; }

ENGINE_MODULE_EXPORT std::int32_t cpp_model_handshake(std::uint64_t hello, EngineHandshakeResponseV2* response) {
    if (!response || (hello & 0xFFFFu) != ENGINE_HS_MAGIC) return -1;
    const auto version = static_cast<std::uint8_t>((hello >> 16) & 0xFFu);
    const auto language = static_cast<std::uint8_t>((hello >> 24) & 0x3u);
    const auto slot = static_cast<std::uint8_t>((hello >> 28) & 0xFFu);
    if (version != ENGINE_HS_VERSION || language != ENGINE_LANG_CPP || slot >= 11) return -2;
    // Negotiation is driven by the first request: even slots choose 64-bit packets,
    // odd slots choose 128-bit packets. Real modules can apply capability policy here.
    g_profile = (slot % 2 == 0) ? ENGINE_PROFILE_64 : ENGINE_PROFILE_128;
    std::uint64_t word0 = ENGINE_HS_MAGIC;
    word0 |= (std::uint64_t(ENGINE_HS_VERSION) << 16);
    word0 |= (std::uint64_t(0) << 24); // status OK
    word0 |= (std::uint64_t(ENGINE_LANG_CPP) << 32);
    word0 |= (std::uint64_t(g_profile) << 34);
    word0 |= (std::uint64_t(slot) << 36);
    word0 |= (std::uint64_t(g_profile == ENGINE_PROFILE_64 ? 8 : 16) << 44);
    word0 |= (std::uint64_t(g_profile == ENGINE_PROFILE_64 ? 8 : 16) << 52);
    word0 |= (std::uint64_t(0xFu) << 60); // supported capability bits
    response->word0 = word0;
    response->word1 = std::uint64_t(ENGINE_CPP_BRIDGE_GROUP) | (std::uint64_t(slot + 1) << 32);
    return 0;
}
ENGINE_MODULE_EXPORT std::uint32_t cpp_model_protocol_version() { return ENGINE_CPP_MODEL_PROTOCOL_VERSION; }
ENGINE_MODULE_EXPORT std::int32_t cpp_model_init(std::uint32_t slot) {
    if (slot >= 11) return -1;
    g_slot = slot; g_initialized = true; return 0;
}
ENGINE_MODULE_EXPORT std::int32_t cpp_model_health() { return g_initialized ? 1 : 0; }

ENGINE_MODULE_EXPORT std::int32_t cpp_model_exchange(const std::uint8_t* input, std::uint32_t input_size,
        std::uint8_t* output, std::uint32_t output_capacity, std::uint32_t* output_size) {
    const std::uint32_t expected = g_profile == ENGINE_PROFILE_64 ? 8u : 16u;
    if (!g_initialized || !input || !output || !output_size || input_size != expected || output_capacity < expected) return -1;
    std::memset(output, 0, expected);
    if (g_profile == ENGINE_PROFILE_64) {
        std::uint64_t in = 0, out = 0; std::memcpy(&in, input, 8);
        // Preserve the incoming token and tag this module in the upper byte.
        out = (in & 0x00FFFFFFFFFFFFFFULL) | (std::uint64_t(g_slot & 0xFFu) << 56);
        std::memcpy(output, &out, 8);
    } else {
        std::uint64_t in0 = 0, in1 = 0, out0 = 0, out1 = 0;
        std::memcpy(&in0, input, 8); std::memcpy(&in1, input + 8, 8);
        out0 = (in0 & 0x0000FFFFFFFFFFFFULL) | (std::uint64_t(g_slot & 0xFFu) << 48);
        out1 = in1 ^ (std::uint64_t(g_slot) << 32);
        std::memcpy(output, &out0, 8); std::memcpy(output + 8, &out1, 8);
    }
    *output_size = expected;
    return 0;
}
ENGINE_MODULE_EXPORT void cpp_model_shutdown() { g_initialized = false; }
