# External module loading and fallback report — v6

## Implemented

- Fixed 21 module slots: Rust `0..=9`, C++ `0..=10`.
- Windows paths: `modules/rust/models 0.dll` … `models 9.dll`; `modules/cpp/models 0.dll` … `models 10.dll`.
- Linux paths use the same stems with `.so`; macOS uses `.dylib`. Native extension is preferred.
- Startup presence check, dynamic library loading, required-export check, ABI version check, init check and health check.
- Core-owned fallback occupies each missing/broken slot without shifting slot IDs.
- Per-frame health check and update result validation; failed module is quarantined and replaced with the core stub, while other modules continue.
- Language-specific protocol exports: `rust_model_*` and `cpp_model_*`, protocol version 1, fixed-layout input/output structures.
- Rust and C++ example module sources, Linux and Windows build scripts, Rust unit tests and native C++ ABI test.

## Tests executed in this environment

The environment contains `g++`, but does not contain `cargo` or `rustc`. Therefore the Rust host, Rust cdylib templates, Cargo tests and full Rust+C++ runtime have **not** been compiled or executed here. They must not be marked as passed until `bash scripts/test_full_stack.sh` completes on a machine with stable Rust and a C++ compiler.

Executed successfully:

1. Compiled all 11 C++ example shared modules with `g++ -std=c++17 -O2 -Wall -Wextra -Werror -fPIC -shared`.
2. Loaded all 11 C++ modules through `dlopen`/`dlsym` test harness; protocol version, init, health, update and output checks passed: `cpp_dynamic_modules=11 protocol=PASS init=PASS health=PASS update=PASS`.
3. Shared table heavy stress: 10 threads, 30,000 increments each, `completed=300000`, `errors=0`, `observed_value=300000`, `exact_match=PASS` (one run: 242 ms).
4. Lease deadline test: `elapsed_ms=120`, configured lease 120 ms, waiter timeout 500 ms: PASS.
5. Atomic update semantics: empty-cell increment, type mismatch (`-4`) and overflow (`-5`, original value unchanged): PASS.
6. C++ shared/private pool stress: 400,000 shared-pool operations and 100,000 local-pool operations, zero errors: PASS.
7. Shell syntax check for test/build scripts: PASS.

## Full-stack verification command

On Linux with stable `cargo`, `rustc`, and `g++`:

```bash
bash scripts/test_full_stack.sh
```

The script builds 10 Rust and 11 C++ example modules, runs Rust unit tests against the actual dynamic loader (including missing and corrupt module fallback tests), checks C++ plugin ABI, then runs native shared-state stress tests. The expected final line is `FULL STACK TEST SUITE: PASS`.

## Limitations and operational notes

- A native module that crashes the process or hangs indefinitely cannot be safely recovered by an in-process loader. The current fallback handles missing files, loader/symbol/version/init/health errors and nonzero update results. Truly untrusted modules require process isolation.
- Automatic discovery occurs at startup. Health and update are checked during runtime. A module file added after startup is picked up on the next restart; live hot-reload is not implemented.
- Rust/C++ structures are C ABI structs; never pass Rust `String`, `Vec`, trait objects, exceptions, or allocator-owned objects across the module boundary.
