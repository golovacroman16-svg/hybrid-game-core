use std::{collections::HashMap, fs, path::{Path, PathBuf}};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AssetKind { Model, Texture, Audio, Shader, Material, Other }

#[derive(Debug, Clone)]
pub struct AssetRecord { pub path: PathBuf, pub kind: AssetKind, pub size_bytes: u64 }

#[derive(Debug, Default)]
pub struct AssetManager {
    root: PathBuf,
    assets: Vec<AssetRecord>,
    by_relative_path: HashMap<PathBuf, usize>,
}

impl AssetManager {
    pub fn scan(root: impl AsRef<Path>) -> Result<Self, String> {
        let root = root.as_ref().to_path_buf();
        fs::create_dir_all(&root).map_err(|e| format!("create {}: {e}", root.display()))?;
        for folder in ["models", "textures", "audio", "shaders", "materials"] {
            fs::create_dir_all(root.join(folder)).map_err(|e| format!("create asset folder: {e}"))?;
        }
        let mut manager = Self { root: root.clone(), ..Self::default() };
        manager.walk(&root)?;
        manager.assets.sort_by(|a, b| a.path.cmp(&b.path));
        for (i, asset) in manager.assets.iter().enumerate() {
            if let Ok(rel) = asset.path.strip_prefix(&root) {
                manager.by_relative_path.insert(rel.to_path_buf(), i);
            }
        }
        Ok(manager)
    }

    fn walk(&mut self, dir: &Path) -> Result<(), String> {
        for entry in fs::read_dir(dir).map_err(|e| format!("read {}: {e}", dir.display()))? {
            let entry = entry.map_err(|e| e.to_string())?;
            let path = entry.path();
            let ty = entry.file_type().map_err(|e| e.to_string())?;
            if ty.is_symlink() { continue; }
            if ty.is_dir() { self.walk(&path)?; }
            else if ty.is_file() {
                let size_bytes = entry.metadata().map_err(|e| e.to_string())?.len();
                let kind = classify(&path);
                self.assets.push(AssetRecord { path, kind, size_bytes });
            }
        }
        Ok(())
    }
    pub fn root(&self) -> &Path { &self.root }
    pub fn all(&self) -> &[AssetRecord] { &self.assets }
    pub fn count(&self) -> usize { self.assets.len() }
    pub fn find(&self, relative: impl AsRef<Path>) -> Option<&AssetRecord> {
        self.by_relative_path.get(relative.as_ref()).and_then(|i| self.assets.get(*i))
    }
    pub fn of_kind(&self, kind: AssetKind) -> impl Iterator<Item=&AssetRecord> {
        self.assets.iter().filter(move |a| a.kind == kind)
    }
}
fn classify(p: &Path) -> AssetKind {
    match p.extension().and_then(|x| x.to_str()).unwrap_or("").to_ascii_lowercase().as_str() {
        "obj" | "fbx" | "gltf" | "glb" | "dae" => AssetKind::Model,
        "png" | "jpg" | "jpeg" | "bmp" | "tga" | "ktx" | "ktx2" | "dds" => AssetKind::Texture,
        "wav" | "ogg" | "mp3" | "flac" => AssetKind::Audio,
        "wgsl" | "glsl" | "vert" | "frag" | "spv" | "hlsl" => AssetKind::Shader,
        "mat" | "material" | "ron" | "toml" => AssetKind::Material,
        _ => AssetKind::Other,
    }
}
