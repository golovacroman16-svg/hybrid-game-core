use std::{
    sync::{Arc, Mutex},
    thread,
    time::Instant,
};
use winit::{
    dpi::LogicalSize,
    event::{ElementState, Event, WindowEvent},
    event_loop::{ControlFlow, EventLoop},
    keyboard::{KeyCode, PhysicalKey},
    window::WindowBuilder,
};

mod physics;
mod opencl;
mod modules;
mod asset_manager;
mod shared_state;
mod module_runtime;

unsafe extern "C" { fn cpp_manager_register(name: *const std::ffi::c_char) -> i32; }

#[derive(Debug, Clone, Copy, Default)]
struct InputState {
    forward: bool,
    backward: bool,
    left: bool,
    right: bool,
    jump_pressed: bool,
    quit: bool,
}

#[derive(Debug, Clone, Copy, Default)]
struct Vec3 {
    x: f32,
    y: f32,
    z: f32,
}

#[derive(Debug, Clone, Copy, Default)]
struct PlayerState {
    position: Vec3,
    velocity: Vec3,
}

#[derive(Debug, Default)]
struct SharedState {
    input: InputState,
    player: PlayerState,
}

fn main() {
    let shared = shared_state::SharedAccess::new(0).expect("valid Rust shared-state module id");
    match shared.acquire(10, 50).and_then(|_| shared.write(20, shared_state::SharedValue::F64(0.0))).and_then(|_| shared.release()) {
        Ok(()) => println!("shared-state: 21-region table ready (Rust/C++ bridge)"),
        Err(e) => eprintln!("shared-state self-check failed: {e}"),
    }

    match asset_manager::AssetManager::scan("assets") {
        Ok(assets) => {
            println!("Asset root: {} ({} files)", assets.root().display(), assets.count());
            for kind in [
                asset_manager::AssetKind::Model,
                asset_manager::AssetKind::Texture,
                asset_manager::AssetKind::Audio,
                asset_manager::AssetKind::Shader,
                asset_manager::AssetKind::Material,
            ] {
                println!("  {kind:?}: {}", assets.of_kind(kind).count());
            }
        }
        Err(error) => eprintln!("Asset scan failed: {error}"),
    }

    // Every external slot is always occupied: a healthy DLL/shared object or a core-owned stub.
    let mut external_modules = module_runtime::ModuleManager::discover("modules");
    let external_counts = external_modules.counts();
    println!("External module slots: loaded={}, core stubs={}, total={}",
        external_counts.loaded, external_counts.stubs, external_modules.slot_count());
    for report in external_modules.reports() {
        if let module_runtime::SlotState::Stub { reason } = report.state {
            eprintln!("module {:?}[{}] -> core stub: {}", report.language, report.slot, reason);
        } else if let Some(path) = report.file {
            println!("module {:?}[{}] loaded from {}", report.language, report.slot, path.display());
        }
    }

    let mut rust_modules = modules::ModuleManager::new();
    rust_modules.register(Box::new(modules::DiagnosticsModule))
        .expect("register diagnostics module");

    let cpp_name = std::ffi::CString::new("physics").unwrap();
    let cpp_physics_rc = unsafe { cpp_manager_register(cpp_name.as_ptr()) };
    let cpp_name = std::ffi::CString::new("opencl").unwrap();
    let cpp_opencl_rc = unsafe { cpp_manager_register(cpp_name.as_ptr()) };
    if cpp_physics_rc < 0 { eprintln!("C++ physics module registration failed: {cpp_physics_rc}"); }
    if cpp_opencl_rc < 0 { eprintln!("C++ OpenCL module registration failed: {cpp_opencl_rc}"); }
    let (rust_count, cpp_count) = modules::ModuleManager::cross_language_counts();
    println!("Built-in module registry: Rust {rust_count}/10, C++ {cpp_count}/11");

    match opencl::device_name() {
        Ok(name) => { println!("OpenCL device: {name}"); match opencl::vector_add(&[1.0, 2.0], &[3.0, 4.0]) { Ok(v) => println!("OpenCL vector-add: {v:?}"), Err(e) => eprintln!("OpenCL compute failed: {e}") } },
        Err(e) => println!("OpenCL unavailable; CPU simulation remains active: {e}"),
    }
    let event_loop = EventLoop::new().expect("failed to create event loop");
    let window = WindowBuilder::new()
        .with_title("Rust + C++ 3D Engine Core")
        .with_inner_size(LogicalSize::new(1100.0, 700.0))
        .build(&event_loop)
        .expect("failed to create window");

    let shared = Arc::new(Mutex::new(SharedState::default()));
    let simulation_shared = Arc::clone(&shared);

    // Simulation/physics worker. It is the only thread that mutates PlayerState.
    let simulation_thread = thread::Builder::new()
        .name("simulation".into())
        .spawn(move || {
            let mut previous = Instant::now();
            loop {
                let now = Instant::now();
                let dt = (now - previous).as_secs_f32().min(0.05);
                previous = now;

                let mut state = simulation_shared.lock().expect("shared state poisoned");
                if state.input.quit {
                    break;
                }

                let mut move_x = 0.0_f32;
                let mut move_z = 0.0_f32;
                if state.input.left { move_x -= 1.0; }
                if state.input.right { move_x += 1.0; }
                // In this engine convention, -Z is forward.
                if state.input.forward { move_z -= 1.0; }
                if state.input.backward { move_z += 1.0; }

                let jump_pressed = state.input.jump_pressed;
                state.input.jump_pressed = false;
                physics::step(&mut state.player, dt, move_x, move_z, jump_pressed);

                drop(state);
                thread::sleep(std::time::Duration::from_millis(4));
            }
        })
        .expect("failed to spawn simulation thread");

    let mut last_title_update = Instant::now();
    let mut last_module_update = Instant::now();
    let mut last_space_down = false;

    event_loop.set_control_flow(ControlFlow::Poll);
    let run_result = event_loop.run(move |event, elwt| {
        match event {
            Event::WindowEvent { event, .. } => match event {
                WindowEvent::CloseRequested => {
                    if let Ok(mut state) = shared.lock() {
                        state.input.quit = true;
                    }
                    elwt.exit();
                }
                WindowEvent::KeyboardInput { event, .. } => {
                    let pressed = event.state == ElementState::Pressed;
                    let key = match event.physical_key {
                        PhysicalKey::Code(code) => code,
                        _ => return,
                    };
                    if let Ok(mut state) = shared.lock() {
                        match key {
                            KeyCode::KeyW => state.input.forward = pressed,
                            KeyCode::KeyA => state.input.left = pressed,
                            KeyCode::KeyS => state.input.backward = pressed,
                            KeyCode::KeyD => state.input.right = pressed,
                            KeyCode::Space => {
                                if pressed && !last_space_down {
                                    state.input.jump_pressed = true;
                                }
                                last_space_down = pressed;
                            }
                            KeyCode::Escape if pressed => {
                                state.input.quit = true;
                                elwt.exit();
                            }
                            _ => {}
                        }
                    }
                }
                _ => {}
            },
            Event::AboutToWait => {
                if last_module_update.elapsed().as_millis() >= 16 {
                    let dt = last_module_update.elapsed().as_secs_f32();
                    let _module_outputs = external_modules.update_all(dt, 0);
                    last_module_update = Instant::now();
                }
                if last_title_update.elapsed().as_millis() >= 100 {
                    if let Ok(state) = shared.lock() {
                        let p = state.player.position;
                        window.set_title(&format!(
                            "Rust + C++ 3D Engine Core | Player: x={:.2} y={:.2} z={:.2} | WASD move, Space jump",
                            p.x, p.y, p.z
                        ));
                    }
                    last_title_update = Instant::now();
                }
            }
            _ => {}
        }
    });

    // The event loop owns the window/input thread. After it exits, join the worker.
    if let Ok(mut state) = shared.lock() {
        state.input.quit = true;
    }
    let _ = simulation_thread.join();
    rust_modules.shutdown_all();
    run_result.expect("event loop failed");
}
