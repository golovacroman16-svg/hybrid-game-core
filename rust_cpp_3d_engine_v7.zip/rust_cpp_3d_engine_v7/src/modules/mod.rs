use std::ffi::CString;
use std::ffi::c_char;
pub const MAX_RUST_MODULES: usize = 10;
unsafe extern "C" {
    fn engine_bridge_register(kind: u32, name: *const c_char) -> i32;
    fn engine_bridge_count(kind: u32) -> u32;
}
pub trait EngineModule: Send {
    fn name(&self) -> &'static str;
    fn initialize(&mut self) -> Result<(), String> { Ok(()) }
    fn update(&mut self, _dt: f32) -> Result<(), String> { Ok(()) }
    fn shutdown(&mut self) {}
}
pub struct ModuleManager { modules: Vec<Box<dyn EngineModule>> }
impl Default for ModuleManager { fn default() -> Self { Self::new() } }
impl ModuleManager {
    pub fn new() -> Self { Self { modules: Vec::with_capacity(MAX_RUST_MODULES) } }
    pub fn register(&mut self, mut module: Box<dyn EngineModule>) -> Result<(), String> {
        let name = module.name();
        if self.modules.len() >= MAX_RUST_MODULES { return Err("Rust module limit (10) reached".into()); }
        if self.modules.iter().any(|m| m.name() == name) { return Err(format!("duplicate Rust module: {name}")); }
        let cname = CString::new(name).map_err(|_| "module name contains NUL".to_string())?;
        let rc = unsafe { engine_bridge_register(0, cname.as_ptr()) };
        if rc < 0 { return Err(format!("shared module registry rejected {name}: {rc}")); }
        module.initialize()?;
        self.modules.push(module);
        Ok(())
    }
    pub fn update_all(&mut self, dt: f32) -> Result<(), String> {
        for m in &mut self.modules { m.update(dt)?; } Ok(())
    }
    pub fn shutdown_all(&mut self) { for m in self.modules.iter_mut().rev() { m.shutdown(); } }
    pub fn len(&self) -> usize { self.modules.len() }
    pub fn cross_language_counts() -> (u32,u32) {
        unsafe { (engine_bridge_count(0), engine_bridge_count(1)) }
    }
}
#[derive(Debug, Default)]
pub struct DiagnosticsModule;
impl EngineModule for DiagnosticsModule { fn name(&self) -> &'static str { "diagnostics" } }
