//! Dynamic module runtime with language-specific 64 -> 128-bit handshakes,
//! negotiated 64/128-bit packets, core stubs, and same-language direct bridges.
use std::{
    collections::HashMap,
    ffi::{CStr, CString},
    path::{Path, PathBuf},
};

pub const PROTOCOL_VERSION: u32 = 2;
pub const HANDSHAKE_MAGIC: u16 = 0x484D;
pub const HANDSHAKE_VERSION: u8 = 2;
pub const RUST_MODULE_COUNT: usize = 10;
pub const CPP_MODULE_COUNT: usize = 11;
pub const PROFILE_64: u8 = 1;
pub const PROFILE_128: u8 = 2;
pub const LANG_RUST: u8 = 1;
pub const LANG_CPP: u8 = 2;

#[repr(C)]
#[derive(Clone, Copy, Default)]
pub struct HandshakeResponseV2 { pub word0: u64, pub word1: u64 }

#[repr(C)]
#[derive(Clone, Copy)]
pub struct RustModuleInputV1 {
    pub struct_size: u32,
    pub protocol_version: u32,
    pub slot: u32,
    pub flags: u32,
    pub frame_index: u64,
    pub delta_seconds: f32,
    pub reserved: u32,
    pub payload: [u8; 64],
}
impl Default for RustModuleInputV1 {
    fn default() -> Self { Self { struct_size: std::mem::size_of::<Self>() as u32, protocol_version: PROTOCOL_VERSION, slot: 0, flags: 0, frame_index: 0, delta_seconds: 0.0, reserved: 0, payload: [0; 64] } }
}
#[repr(C)]
#[derive(Clone, Copy)]
pub struct RustModuleOutputV1 {
    pub struct_size: u32,
    pub protocol_version: u32,
    pub status: i32,
    pub flags: u32,
    pub value: f64,
    pub message: [i8; 128],
}
impl Default for RustModuleOutputV1 {
    fn default() -> Self { Self { struct_size: std::mem::size_of::<Self>() as u32, protocol_version: PROTOCOL_VERSION, status: 0, flags: 0, value: 0.0, message: [0; 128] } }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ModuleLanguage { Rust, Cpp }
impl ModuleLanguage {
    fn folder(self) -> &'static str { match self { Self::Rust => "rust", Self::Cpp => "cpp" } }
    fn count(self) -> usize { match self { Self::Rust => RUST_MODULE_COUNT, Self::Cpp => CPP_MODULE_COUNT } }
    fn prefix(self) -> &'static str { match self { Self::Rust => "rust_model_", Self::Cpp => "cpp_model_" } }
    fn code(self) -> u8 { match self { Self::Rust => LANG_RUST, Self::Cpp => LANG_CPP } }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SlotState { Loaded { profile_bits: u8, bridge_group: u32, module_id: u32 }, Stub { reason: String } }
#[derive(Debug, Clone)]
pub struct SlotReport { pub language: ModuleLanguage, pub slot: usize, pub file: Option<PathBuf>, pub state: SlotState }
#[derive(Debug, Clone, Copy, Default)]
pub struct RuntimeCounts { pub loaded: usize, pub stubs: usize }

type VersionFn = unsafe extern "C" fn() -> u32;
type HandshakeFn = unsafe extern "C" fn(u64, *mut HandshakeResponseV2) -> i32;
type InitFn = unsafe extern "C" fn(u32) -> i32;
type ExchangeFn = unsafe extern "C" fn(*const u8, u32, *mut u8, u32, *mut u32) -> i32;
type HealthFn = unsafe extern "C" fn() -> i32;
type ShutdownFn = unsafe extern "C" fn();

struct LoadedPlugin {
    _library: DynamicLibrary,
    exchange: ExchangeFn,
    health: HealthFn,
    shutdown: ShutdownFn,
    profile: u8,
    bridge_group: u32,
    module_id: u32,
}
impl Drop for LoadedPlugin { fn drop(&mut self) { unsafe { (self.shutdown)(); } } }
enum Backend { Plugin(LoadedPlugin), Stub { reason: String } }
struct ModuleSlot { language: ModuleLanguage, index: usize, file: Option<PathBuf>, backend: Backend }
pub struct ModuleManager { slots: Vec<ModuleSlot>, frame_index: u64 }

impl ModuleManager {
    /// Root contains rust/models N.{dll,so,dylib} and cpp/models N.{dll,so,dylib}.
    pub fn discover(root: impl AsRef<Path>) -> Self {
        let root = root.as_ref();
        let mut slots = Vec::with_capacity(RUST_MODULE_COUNT + CPP_MODULE_COUNT);
        for language in [ModuleLanguage::Rust, ModuleLanguage::Cpp] {
            for index in 0..language.count() {
                let (backend, file) = Self::load_slot(language, index, &root.join(language.folder()));
                slots.push(ModuleSlot { language, index, file, backend });
            }
        }
        Self { slots, frame_index: 0 }
    }
    fn load_slot(language: ModuleLanguage, index: usize, base: &Path) -> (Backend, Option<PathBuf>) {
        let stem = format!("models {index}");
        let mut candidates = Vec::new();
        #[cfg(target_os = "windows")] { candidates.push(base.join(format!("{stem}.dll"))); }
        #[cfg(target_os = "linux")] { candidates.push(base.join(format!("{stem}.so"))); candidates.push(base.join(format!("{stem}.dll"))); }
        #[cfg(target_os = "macos")] { candidates.push(base.join(format!("{stem}.dylib"))); candidates.push(base.join(format!("{stem}.dll"))); }
        #[cfg(not(any(target_os = "windows", target_os = "linux", target_os = "macos")))] { candidates.push(base.join(format!("{stem}.dll"))); }
        let mut errors = Vec::new(); let mut last_existing = None;
        for path in candidates {
            if !path.is_file() { continue; }
            last_existing = Some(path.clone());
            match unsafe { Self::load_plugin(language, index, &path) } {
                Ok(p) => return (Backend::Plugin(p), Some(path)),
                Err(e) => errors.push(format!("{}: {e}", path.display())),
            }
        }
        let reason = if errors.is_empty() { format!("module file absent; core stub occupies {} slot {index}", language.folder()) }
            else { format!("handshake/load failed; core stub occupies {} slot {index}: {}", language.folder(), errors.join("; ")) };
        (Backend::Stub { reason }, last_existing)
    }
    unsafe fn load_plugin(language: ModuleLanguage, index: usize, path: &Path) -> Result<LoadedPlugin, String> {
        let library = DynamicLibrary::open(path).map_err(|e| format!("dynamic load failed: {e}"))?;
        let p = language.prefix();
        let version: VersionFn = library.symbol(&format!("{p}protocol_version"))?;
        let handshake: HandshakeFn = library.symbol(&format!("{p}handshake"))?;
        let init: InitFn = library.symbol(&format!("{p}init"))?;
        let exchange: ExchangeFn = library.symbol(&format!("{p}exchange"))?;
        let health: HealthFn = library.symbol(&format!("{p}health"))?;
        let shutdown: ShutdownFn = library.symbol(&format!("{p}shutdown"))?;
        if version() != PROTOCOL_VERSION { return Err(format!("protocol version {}, expected {}", version(), PROTOCOL_VERSION)); }
        // The very first module message is 64 bits. Its response is 128 bits.
        let hello = encode_hello(language, index as u8, PROFILE_128);
        let mut response = HandshakeResponseV2::default();
        if handshake(hello, &mut response) != 0 { return Err("module rejected 64-bit handshake request".into()); }
        let fields = decode_handshake(response);
        if fields.status != 0 { return Err(format!("handshake status {}", fields.status)); }
        if fields.language != language.code() { return Err("handshake language mismatch".into()); }
        if fields.slot as usize != index { return Err("handshake slot mismatch".into()); }
        if fields.profile != PROFILE_64 && fields.profile != PROFILE_128 { return Err("unsupported negotiated packet profile".into()); }
        let expected = if fields.profile == PROFILE_64 { 8 } else { 16 };
        if fields.input_size != expected || fields.output_size != expected { return Err("handshake packet size/profile mismatch".into()); }
        if init(index as u32) != 0 { shutdown(); return Err("module init returned failure".into()); }
        if health() <= 0 { shutdown(); return Err("module health check failed".into()); }
        Ok(LoadedPlugin { _library: library, exchange, health, shutdown, profile: fields.profile, bridge_group: fields.bridge_group, module_id: fields.module_id })
    }
    pub fn counts(&self) -> RuntimeCounts {
        let mut c = RuntimeCounts::default();
        for s in &self.slots { match &s.backend { Backend::Plugin(_) => c.loaded += 1, Backend::Stub { .. } => c.stubs += 1 } }
        c
    }
    pub fn reports(&self) -> Vec<SlotReport> {
        self.slots.iter().map(|s| SlotReport { language: s.language, slot: s.index, file: s.file.clone(), state: match &s.backend {
            Backend::Plugin(p) => SlotState::Loaded { profile_bits: p.profile * 64, bridge_group: p.bridge_group, module_id: p.module_id },
            Backend::Stub { reason } => SlotState::Stub { reason: reason.clone() },
        }}).collect()
    }
    pub fn slot_count(&self) -> usize { self.slots.len() }

    /// Same-language direct bridge: the prior module's raw output is passed to the next
    /// module only when language, bridge_group and negotiated profile all match.
    /// C++ and Rust routes are intentionally kept in separate maps.
    pub fn update_all(&mut self, delta_seconds: f32, flags: u32) -> Vec<RustModuleOutputV1> {
        let mut outputs = Vec::with_capacity(self.slots.len());
        let mut routes: HashMap<(ModuleLanguage, u32, u8), Vec<u8>> = HashMap::new();
        for slot in &mut self.slots {
            let language = slot.language; let index = slot.index;
            let dt = if delta_seconds.is_finite() { delta_seconds.clamp(0.0, 0.25) } else { 0.0 };
            let mut output = RustModuleOutputV1::default();
            let mut outgoing_route: Option<((ModuleLanguage, u32, u8), Vec<u8>)> = None;
            let mut failure = None;
            match &mut slot.backend {
                Backend::Plugin(plugin) => unsafe {
                    if (plugin.health)() <= 0 { failure = Some("runtime health check failed".to_string()); }
                    else {
                        let key = (language, plugin.bridge_group, plugin.profile);
                        let input = routes.get(&key).cloned().unwrap_or_else(|| seed_packet(plugin.profile, self.frame_index, index as u32, flags, dt));
                        let mut wire_out = vec![0u8; input.len()]; let mut written = 0u32;
                        if (plugin.exchange)(input.as_ptr(), input.len() as u32, wire_out.as_mut_ptr(), wire_out.len() as u32, &mut written) != 0 {
                            failure = Some("exchange returned failure".to_string());
                        } else if written as usize != wire_out.len() {
                            failure = Some(format!("exchange wrote {written} bytes; expected {}", wire_out.len()));
                        } else {
                            decode_wire_output(&mut output, &wire_out, language, index, plugin.profile, self.frame_index);
                            outgoing_route = Some((key, wire_out));
                        }
                    }
                },
                Backend::Stub { reason } => fill_stub_output(&mut output, language, index, reason),
            }
            if let Some(reason) = failure {
                slot.backend = Backend::Stub { reason: reason.clone() };
                fill_stub_output(&mut output, language, index, &reason);
                eprintln!("module {:?}[{}] quarantined: {reason}", language, index);
            } else if let Some((key, packet)) = outgoing_route { routes.insert(key, packet); }
            outputs.push(output);
        }
        self.frame_index = self.frame_index.wrapping_add(1);
        outputs
    }
}

struct HandshakeFields { status: u8, language: u8, profile: u8, slot: u8, input_size: u8, output_size: u8, bridge_group: u32, module_id: u32 }
fn encode_hello(language: ModuleLanguage, slot: u8, preferred_profile: u8) -> u64 {
    (HANDSHAKE_MAGIC as u64) | ((HANDSHAKE_VERSION as u64) << 16) | ((language.code() as u64) << 24)
        | ((slot as u64) << 28) | ((preferred_profile as u64 & 0x3) << 36)
}
fn decode_handshake(r: HandshakeResponseV2) -> HandshakeFields {
    HandshakeFields { status: ((r.word0 >> 24) & 0xFF) as u8, language: ((r.word0 >> 32) & 0x3) as u8,
        profile: ((r.word0 >> 34) & 0x3) as u8, slot: ((r.word0 >> 36) & 0xFF) as u8,
        input_size: ((r.word0 >> 44) & 0xFF) as u8, output_size: ((r.word0 >> 52) & 0xFF) as u8,
        bridge_group: r.word1 as u32, module_id: (r.word1 >> 32) as u32 }
}
fn seed_packet(profile: u8, frame: u64, slot: u32, flags: u32, dt: f32) -> Vec<u8> {
    if profile == PROFILE_64 {
        // [frame low 32][slot 8][flags low 8][delta microseconds 16]
        let dt_us = (dt.max(0.0) * 1_000_000.0).round().clamp(0.0, 65535.0) as u64;
        let word = (frame & 0xFFFF_FFFF) | (((slot as u64) & 0xFF) << 32) | (((flags as u64) & 0xFF) << 40) | (dt_us << 48);
        word.to_ne_bytes().to_vec()
    } else {
        let word0 = frame;
        let word1 = (dt.to_bits() as u64) | ((flags as u64) << 32);
        let mut packet = Vec::with_capacity(16);
        packet.extend_from_slice(&word0.to_ne_bytes());
        packet.extend_from_slice(&word1.to_ne_bytes());
        packet
    }
}
fn decode_wire_output(out: &mut RustModuleOutputV1, packet: &[u8], language: ModuleLanguage, slot: usize, profile: u8, frame: u64) {
    *out = RustModuleOutputV1::default(); out.protocol_version = PROTOCOL_VERSION; out.status = 0; out.flags = slot as u32;
    out.value = if profile == PROFILE_64 { u64::from_ne_bytes(packet[..8].try_into().unwrap()) as f64 }
        else { f64::from_bits(u64::from_ne_bytes(packet[8..16].try_into().unwrap())) };
    let msg = format!("{:?}[{}] handshake-v2 profile={} frame={} direct-bridge", language, slot, profile * 64, frame);
    for (dst, src) in out.message.iter_mut().zip(msg.as_bytes().iter().copied()) { *dst = src as i8; }
}
fn fill_stub_output(out: &mut RustModuleOutputV1, language: ModuleLanguage, slot: usize, reason: &str) {
    *out = RustModuleOutputV1::default(); out.status = 1; out.flags = slot as u32;
    let text = format!("CORE_STUB {:?}[{}]: {}", language, slot, reason);
    for (dst, src) in out.message.iter_mut().zip(text.as_bytes().iter().copied()) { *dst = src as i8; }
}

struct DynamicLibrary { handle: *mut std::ffi::c_void }
impl DynamicLibrary {
    unsafe fn symbol<T: Copy>(&self, name: &str) -> Result<T, String> {
        let cname = CString::new(name).map_err(|_| "invalid symbol name".to_string())?;
        let ptr = platform::symbol(self.handle, &cname)?;
        if ptr.is_null() { return Err(format!("missing symbol {name}")); }
        Ok(std::mem::transmute_copy::<*mut std::ffi::c_void, T>(&ptr))
    }
    unsafe fn open(path: &Path) -> Result<Self, String> { Ok(Self { handle: platform::open(path)? }) }
}
impl Drop for DynamicLibrary { fn drop(&mut self) { unsafe { platform::close(self.handle); } } }
#[cfg(unix)]
mod platform {
    use super::*; use std::os::unix::ffi::OsStrExt; const RTLD_NOW: i32 = 2;
    extern "C" { fn dlopen(filename: *const i8, flags: i32) -> *mut std::ffi::c_void; fn dlsym(handle: *mut std::ffi::c_void, symbol: *const i8) -> *mut std::ffi::c_void; fn dlclose(handle: *mut std::ffi::c_void) -> i32; }
    pub unsafe fn open(path: &Path) -> Result<*mut std::ffi::c_void, String> { let p = CString::new(path.as_os_str().as_bytes()).map_err(|_| "path contains NUL".to_string())?; let h = dlopen(p.as_ptr(), RTLD_NOW); if h.is_null() { Err("dlopen failed (missing dependency or invalid library)".into()) } else { Ok(h) } }
    pub unsafe fn symbol(h: *mut std::ffi::c_void, n: &CStr) -> Result<*mut std::ffi::c_void, String> { let p = dlsym(h, n.as_ptr()); if p.is_null() { Err(format!("symbol {} not found", n.to_string_lossy())) } else { Ok(p) } }
    pub unsafe fn close(h: *mut std::ffi::c_void) { if !h.is_null() { let _ = dlclose(h); } }
}
#[cfg(windows)]
mod platform {
    use super::*; use std::os::windows::ffi::OsStrExt;
    #[link(name = "kernel32")] extern "system" { fn LoadLibraryW(name: *const u16) -> *mut std::ffi::c_void; fn GetProcAddress(handle: *mut std::ffi::c_void, name: *const i8) -> *mut std::ffi::c_void; fn FreeLibrary(handle: *mut std::ffi::c_void) -> i32; }
    pub unsafe fn open(path: &Path) -> Result<*mut std::ffi::c_void, String> { let w: Vec<u16> = path.as_os_str().encode_wide().chain(std::iter::once(0)).collect(); let h = LoadLibraryW(w.as_ptr()); if h.is_null() { Err("LoadLibraryW failed".into()) } else { Ok(h) } }
    pub unsafe fn symbol(h: *mut std::ffi::c_void, n: &CStr) -> Result<*mut std::ffi::c_void, String> { let p = GetProcAddress(h, n.as_ptr()); if p.is_null() { Err(format!("symbol {} not found", n.to_string_lossy())) } else { Ok(p) } }
    pub unsafe fn close(h: *mut std::ffi::c_void) { if !h.is_null() { let _ = FreeLibrary(h); } }
}
#[cfg(not(any(unix, windows)))]
mod platform { use super::*; pub unsafe fn open(_: &Path) -> Result<*mut std::ffi::c_void, String> { Err("dynamic loading unsupported".into()) } pub unsafe fn symbol(_: *mut std::ffi::c_void, _: &CStr) -> Result<*mut std::ffi::c_void, String> { Err("dynamic loading unsupported".into()) } pub unsafe fn close(_: *mut std::ffi::c_void) {} }

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn handshake_is_64_request_128_response_and_profiles_decode() {
        let hello = encode_hello(ModuleLanguage::Rust, 3, PROFILE_128);
        assert!(hello.count_ones() <= 64);
        let response = HandshakeResponseV2 { word0: (HANDSHAKE_MAGIC as u64) | ((HANDSHAKE_VERSION as u64) << 16) | ((LANG_RUST as u64) << 32) | ((PROFILE_128 as u64) << 34) | (3u64 << 36) | (16u64 << 44) | (16u64 << 52), word1: 7 | (4u64 << 32) };
        let f = decode_handshake(response); assert_eq!(f.profile, PROFILE_128); assert_eq!(f.input_size, 16); assert_eq!(f.output_size, 16); assert_eq!(f.bridge_group, 7); assert_eq!(f.module_id, 4);
    }
    #[test] fn packets_have_negotiated_sizes() {
        assert_eq!(seed_packet(PROFILE_64, 1, 2, 3, 0.016).len(), 8);
        assert_eq!(seed_packet(PROFILE_128, 1, 2, 3, 0.016).len(), 16);
    }
    #[test] fn absent_modules_keep_all_slots_via_core_stubs() {
        let root = std::env::temp_dir().join(format!("engine-module-test-{}", std::process::id())); let _ = std::fs::remove_dir_all(&root); std::fs::create_dir_all(&root).unwrap();
        let mut manager = ModuleManager::discover(&root); assert_eq!(manager.slot_count(), 21); assert_eq!(manager.counts().loaded, 0); assert_eq!(manager.counts().stubs, 21);
        let outputs = manager.update_all(1.0 / 60.0, 0); assert_eq!(outputs.len(), 21); assert!(outputs.iter().all(|o| o.status == 1 && o.protocol_version == PROTOCOL_VERSION)); let _ = std::fs::remove_dir_all(&root);
    }
    #[test] fn built_example_plugins_load_and_run_when_requested() {
        let Ok(root) = std::env::var("ENGINE_TEST_PLUGIN_DIR") else { return; };
        let mut manager = ModuleManager::discover(root); assert_eq!(manager.counts().loaded, 21, "all example modules should load"); assert_eq!(manager.counts().stubs, 0);
        let outputs = manager.update_all(1.0 / 60.0, 0); assert_eq!(outputs.len(), 21); assert!(outputs.iter().all(|o| o.status == 0 && o.protocol_version == PROTOCOL_VERSION));
    }
    #[test] fn broken_module_becomes_stub() {
        let root = std::env::temp_dir().join(format!("engine-module-broken-{}", std::process::id())); let _ = std::fs::remove_dir_all(&root); std::fs::create_dir_all(root.join("rust")).unwrap();
        #[cfg(target_os = "linux")] let bad = root.join("rust/models 0.so");
        #[cfg(target_os = "windows")] let bad = root.join("rust/models 0.dll");
        #[cfg(target_os = "macos")] let bad = root.join("rust/models 0.dylib");
        std::fs::write(&bad, b"not a dynamic library").unwrap(); let mut manager = ModuleManager::discover(&root); assert_eq!(manager.counts().stubs, 21); assert!(manager.update_all(0.016, 0).iter().all(|o| o.status == 1)); let _ = std::fs::remove_dir_all(&root);
    }
}
