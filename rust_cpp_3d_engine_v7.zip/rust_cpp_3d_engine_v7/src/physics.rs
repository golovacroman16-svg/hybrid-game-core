use crate::PlayerState;

unsafe extern "C" {
    fn physics_step(
        px: *mut f32, py: *mut f32, pz: *mut f32,
        vx: *mut f32, vy: *mut f32, vz: *mut f32,
        dt: f32,
        move_x: f32, move_z: f32,
        move_speed: f32,
        gravity: f32,
        jump_velocity: f32,
        jump_pressed: i32,
    );
}

/// Rust owns the PlayerState; C++ receives only pointers to its scalar fields
/// during this call. The simulation thread is the only writer.
pub fn step(player: &mut PlayerState, dt: f32, move_x: f32, move_z: f32, jump_pressed: bool) {
    let p = &mut player.position;
    let v = &mut player.velocity;
    // SAFETY: pointers are valid for this synchronous call, are non-null, and
    // the C++ function does not retain them after returning.
    unsafe {
        physics_step(
            &mut p.x, &mut p.y, &mut p.z,
            &mut v.x, &mut v.y, &mut v.z,
            dt,
            move_x, move_z,
            5.0,       // movement speed, metres/second
            -9.81,     // gravity, metres/second^2
            5.0,       // jump velocity, metres/second
            i32::from(jump_pressed),
        );
    }
}
