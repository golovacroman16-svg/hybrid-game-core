//! Cross-language shared table and language-private memory pools.
use std::ffi::{c_char,c_int};
use std::sync::{Mutex,OnceLock,RwLock};
pub const COMMON_REGION_COUNT:usize=21; pub const MODULES_PER_LANGUAGE:usize=5; pub const RUST_POOL_CAPACITY:usize=64; pub const LOCAL_POOL_CAPACITY:usize=32; pub const MAX_LEASE_MS:u32=1000;
pub const SLOT_NAMES:[&str;21]=["simulation_time","delta_time","player_position","player_velocity","input_mask","world_seed","active_scene","physics_tick","frame_index","entity_count","camera_position","camera_direction","gravity","collision_count","audio_state","render_state","asset_generation","game_state","debug_flags","network_tick","user_scalar"];
#[repr(C)] #[derive(Clone,Copy,Debug)] pub struct RawValue{pub kind:u32,pub i64_value:i64,pub f64_value:f64,pub vec3:[f64;3],pub text:[c_char;128]}
impl Default for RawValue{fn default()->Self{Self{kind:0,i64_value:0,f64_value:0.0,vec3:[0.0;3],text:[0;128]}}}
#[derive(Clone,Debug,PartialEq)] pub enum SharedValue{I64(i64),F64(f64),Bool(bool),Vec3([f64;3]),Text(String)}
impl SharedValue{
 fn to_raw(&self)->Result<RawValue,String>{let mut r=RawValue::default();match self{Self::I64(v)=>{r.kind=1;r.i64_value=*v},Self::F64(v)=>{r.kind=2;r.f64_value=*v},Self::Bool(v)=>{r.kind=3;r.i64_value=i64::from(*v)},Self::Vec3(v)=>{r.kind=4;r.vec3=*v},Self::Text(v)=>{if v.as_bytes().len()>=128{return Err("shared text must be shorter than 128 UTF-8 bytes".into())}r.kind=5;for(i,b)in v.as_bytes().iter().enumerate(){r.text[i]=*b as c_char}}}Ok(r)}
 fn from_raw(r:RawValue)->Result<Option<Self>,String>{match r.kind{0=>Ok(None),1=>Ok(Some(Self::I64(r.i64_value))),2=>Ok(Some(Self::F64(r.f64_value))),3=>Ok(Some(Self::Bool(r.i64_value!=0))),4=>Ok(Some(Self::Vec3(r.vec3))),5=>{let bytes:Vec<u8>=r.text.iter().take_while(|&&c|c!=0).map(|&c|c as u8).collect();Ok(Some(Self::Text(String::from_utf8(bytes).map_err(|e|format!("invalid shared UTF-8: {e}"))?)))},n=>Err(format!("unknown shared value type {n}"))}}
}
unsafe extern "C"{fn engine_shared_acquire(lang:u32,id:u32,timeout:u32,lease:u32)->c_int;fn engine_shared_release(lang:u32,id:u32)->c_int;fn engine_shared_read(lang:u32,id:u32,slot:u32,out:*mut RawValue)->c_int;fn engine_shared_write(lang:u32,id:u32,slot:u32,value:*const RawValue)->c_int;fn engine_shared_update(lang:u32,id:u32,slot:u32,delta:i64,out:*mut RawValue)->c_int;fn engine_shared_value_size()->u32;}
#[derive(Clone,Copy,Debug)] pub struct SharedAccess{module_id:u32}
impl SharedAccess{
 pub fn new(module_id:u32)->Result<Self,String>{if module_id>=5{return Err("Rust shared-state module_id must be 0..4".into())}Ok(Self{module_id})}
 pub fn acquire(&self,timeout_ms:u32,lease_ms:u32)->Result<(),String>{if lease_ms==0||lease_ms>MAX_LEASE_MS{return Err("lease_ms must be in 1..=1000".into())}check(unsafe{engine_shared_acquire(0,self.module_id,timeout_ms,lease_ms)},"acquire shared table")}
 pub fn release(&self)->Result<(),String>{check(unsafe{engine_shared_release(0,self.module_id)},"release shared table")}
 pub fn read(&self,slot:usize)->Result<Option<SharedValue>,String>{if slot>=21{return Err("common-table slot must be 0..20".into())}let mut r=RawValue::default();check(unsafe{engine_shared_read(0,self.module_id,slot as u32,&mut r)},"read shared table")?;SharedValue::from_raw(r)}
 pub fn write(&self,slot:usize,value:SharedValue)->Result<(),String>{if slot>=21{return Err("common-table slot must be 0..20".into())}let r=value.to_raw()?;check(unsafe{engine_shared_write(0,self.module_id,slot as u32,&r)},"write shared table")}
 pub fn update_i64(&self,slot:usize,delta:i64)->Result<i64,String>{if slot>=21{return Err("common-table slot must be 0..20".into())}let mut r=RawValue::default();check(unsafe{engine_shared_update(0,self.module_id,slot as u32,delta,&mut r)},"atomic update shared table")?;if r.kind!=1{return Err("native atomic update returned a non-I64 value".into())}Ok(r.i64_value)}
}
fn check(rc:c_int,op:&str)->Result<(),String>{match rc{0=>Ok(()),-1=>Err(format!("{op}: lease unavailable, expired, or timed out")),-2=>Err(format!("{op}: invalid argument or value")),-3=>Err(format!("{op}: module already holds a lease")),-4=>Err(format!("{op}: atomic update requires an I64 or empty cell")),-5=>Err(format!("{op}: signed 64-bit overflow")),n=>Err(format!("{op}: native error {n}"))}}
static RUST_POOL:OnceLock<RwLock<Vec<Option<SharedValue>>>>=OnceLock::new();static RUST_LOCAL:OnceLock<Mutex<Vec<Vec<Option<SharedValue>>>>>=OnceLock::new();
fn rust_pool()->&'static RwLock<Vec<Option<SharedValue>>>{RUST_POOL.get_or_init(||RwLock::new(vec![None;64]))}
fn local_pools()->&'static Mutex<Vec<Vec<Option<SharedValue>>>>{RUST_LOCAL.get_or_init(||Mutex::new((0..5).map(|_|vec![None;32]).collect()))}
pub fn rust_pool_set(key:usize,value:SharedValue)->Result<(),String>{let mut p=rust_pool().write().map_err(|_|"Rust pool lock poisoned".to_string())?;*p.get_mut(key).ok_or("Rust pool key must be 0..63")?=Some(value);Ok(())}
pub fn rust_pool_get(key:usize)->Result<Option<SharedValue>,String>{let p=rust_pool().read().map_err(|_|"Rust pool lock poisoned".to_string())?;p.get(key).cloned().ok_or_else(||"Rust pool key must be 0..63".into())}
pub fn rust_local_set(id:usize,key:usize,value:SharedValue)->Result<(),String>{let mut p=local_pools().lock().map_err(|_|"Rust local-pool lock poisoned".to_string())?;*p.get_mut(id).ok_or("Rust module_id must be 0..4")?.get_mut(key).ok_or("Rust local key must be 0..31")?=Some(value);Ok(())}
pub fn rust_local_get(id:usize,key:usize)->Result<Option<SharedValue>,String>{let p=local_pools().lock().map_err(|_|"Rust local-pool lock poisoned".to_string())?;p.get(id).ok_or("Rust module_id must be 0..4")?.get(key).cloned().ok_or_else(||"Rust local key must be 0..31".into())}


#[cfg(test)]
mod tests {
    use super::*;
    use std::mem::size_of;
    use std::sync::{Barrier, Mutex as StdMutex};
    use std::thread;
    use std::time::{Duration, Instant};

    // The native table and leases are process-global. Serialize tests that mutate them.
    static TEST_LOCK: StdMutex<()> = StdMutex::new(());

    #[test]
    fn rust_ffi_layout_matches_native_value() {
        let _serial = TEST_LOCK.lock().expect("test lock poisoned");
        assert_eq!(size_of::<RawValue>(), 176, "unexpected Rust C ABI layout");
        let native_size = unsafe { engine_shared_value_size() } as usize;
        assert_eq!(size_of::<RawValue>(), native_size, "Rust/C++ EngineSharedValue layout mismatch");
    }

    #[test]
    fn rust_threads_atomic_increment_shared_cpp_table() {
        let _serial = TEST_LOCK.lock().expect("test lock poisoned");
        const THREADS: usize = 5;
        const UPDATES_PER_THREAD: usize = 30_000;
        const SLOT: usize = 20;

        let init = SharedAccess::new(0).unwrap();
        init.acquire(100, MAX_LEASE_MS).unwrap();
        init.write(SLOT, SharedValue::I64(0)).unwrap();
        init.release().unwrap();

        let start = std::sync::Arc::new(Barrier::new(THREADS));
        let began = Instant::now();
        let mut workers = Vec::with_capacity(THREADS);
        for module_id in 0..THREADS {
            let start = start.clone();
            workers.push(thread::Builder::new()
                .name(format!("rust-shared-update-{module_id}"))
                .spawn(move || {
                    let access = SharedAccess::new(module_id as u32).unwrap();
                    access.acquire(100, MAX_LEASE_MS).unwrap();
                    start.wait();
                    for _ in 0..UPDATES_PER_THREAD {
                        access.update_i64(SLOT, 1).unwrap();
                    }
                    access.release().unwrap();
                }).unwrap());
        }
        for worker in workers { worker.join().expect("Rust update worker panicked"); }
        let elapsed = began.elapsed();

        init.acquire(100, MAX_LEASE_MS).unwrap();
        let actual = init.read(SLOT).unwrap();
        init.release().unwrap();
        assert_eq!(actual, Some(SharedValue::I64((THREADS * UPDATES_PER_THREAD) as i64)));
        eprintln!("rust_shared_heavy threads={THREADS} updates={} elapsed_ms={} result={actual:?}", THREADS * UPDATES_PER_THREAD, elapsed.as_millis());
    }

    #[test]
    fn rust_private_pools_are_thread_safe_under_load() {
        let _serial = TEST_LOCK.lock().expect("test lock poisoned");
        const THREADS: usize = 5;
        const LOOPS: i64 = 10_000;
        let mut workers = Vec::new();
        for module_id in 0..THREADS {
            workers.push(thread::Builder::new()
                .name(format!("rust-private-pool-{module_id}"))
                .spawn(move || {
                    for n in 0..LOOPS {
                        rust_pool_set(module_id, SharedValue::I64(n)).unwrap();
                        assert_eq!(rust_pool_get(module_id).unwrap(), Some(SharedValue::I64(n)));
                        rust_local_set(module_id, module_id, SharedValue::I64(n)).unwrap();
                        assert_eq!(rust_local_get(module_id, module_id).unwrap(), Some(SharedValue::I64(n)));
                    }
                }).unwrap());
        }
        for worker in workers { worker.join().expect("Rust pool worker panicked"); }
        eprintln!("rust_private_pools threads={THREADS} loops_per_thread={LOOPS} errors=0");
    }

    #[test]
    fn cpp_waiter_wakes_at_rust_lease_deadline() {
        let _serial = TEST_LOCK.lock().expect("test lock poisoned");
        let owner = SharedAccess::new(0).unwrap();
        owner.acquire(100, 250).unwrap();

        let waiter = thread::Builder::new()
            .name("rust-thread-calling-cpp-lease-api".into())
            .spawn(|| {
                let started = Instant::now();
                let rc = unsafe { engine_shared_acquire(1, 0, 500, 100) };
                let elapsed = started.elapsed();
                if rc == 0 {
                    let release_rc = unsafe { engine_shared_release(1, 0) };
                    assert_eq!(release_rc, 0, "C++-language lease release failed");
                }
                (rc, elapsed)
            }).unwrap();

        let (rc, elapsed) = waiter.join().expect("lease waiter panicked");
        assert_eq!(rc, 0, "C++-language waiter did not acquire after expiry");
        assert!(elapsed >= Duration::from_millis(150), "waiter woke too early: {elapsed:?}");
        assert!(elapsed < Duration::from_millis(450), "waiter missed lease deadline: {elapsed:?}");
        // The Rust lease is expected to have expired while the competing-language waiter ran.
        eprintln!("rust_to_cpp_lease_wait elapsed_ms={} lease_ms=250 timeout_ms=500 result=PASS", elapsed.as_millis());
    }
}
