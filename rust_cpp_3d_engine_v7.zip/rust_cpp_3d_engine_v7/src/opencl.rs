use std::ffi::{c_char,CStr};
unsafe extern "C" {fn ocl12_is_available()->i32;fn ocl12_get_device_name(out:*mut c_char,cap:usize)->i32;fn ocl12_vector_add(a:*const f32,b:*const f32,out:*mut f32,n:usize)->i32;fn ocl12_last_error()->*const c_char;}
fn error()->String{unsafe{let p=ocl12_last_error();if p.is_null(){"unknown OpenCL error".into()}else{CStr::from_ptr(p).to_string_lossy().into_owned()}}}
pub fn device_name()->Result<String,String>{unsafe{if ocl12_is_available()==0{return Err(error())}let mut b=vec![0_i8;512];if ocl12_get_device_name(b.as_mut_ptr(),b.len())<0{return Err(error())}Ok(CStr::from_ptr(b.as_ptr()).to_string_lossy().into_owned())}}
pub fn vector_add(a:&[f32],b:&[f32])->Result<Vec<f32>,String>{if a.len()!=b.len(){return Err("vector lengths differ".into())}let mut out=vec![0.;a.len()];unsafe{let rc=ocl12_vector_add(a.as_ptr(),b.as_ptr(),out.as_mut_ptr(),a.len());if rc!=0{return Err(error())}}Ok(out)}
