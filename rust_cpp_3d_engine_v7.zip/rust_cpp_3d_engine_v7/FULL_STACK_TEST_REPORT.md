# Rust + C++ full-stack integration and stress-test report

Date: 2026-10-17

## Scope

This revision adds Cargo-level Rust tests that call the real C ABI linked to `cpp/shared_memory.cpp`, plus tests of Rust-only thread-safe pools. It also adds a repeatable script and GitHub Actions workflow to compile and test the complete Rust/C++ application.

## Changes made

- Added Rust unit tests in `src/shared_state.rs`:
  - `rust_threads_atomic_increment_shared_cpp_table`: five real Rust threads, 30,000 atomic increments per thread, expected exact value 150,000.
  - `rust_private_pools_are_thread_safe_under_load`: five Rust threads concurrently exercise `RwLock` shared pool and `Mutex` module-local pools, 10,000 iterations per thread.
  - `cpp_waiter_wakes_at_rust_lease_deadline`: a Rust thread calls the C++-language lease API while a Rust lease is held; a 250 ms lease must release the waiter well before its 500 ms timeout.
  - `rust_ffi_layout_matches_native_value`: compares `size_of::<RawValue>()` with `sizeof(EngineSharedValue)` reported by C++.
- Added `engine_shared_value_size()` to the native C ABI for a direct ABI layout assertion.
- Added `scripts/test_full_stack.sh`, which runs Rust tests, builds the executable, and compiles/runs the native C++ regression tests.
- Added `.github/workflows/rust-cpp-ci.yml` to run the full-stack script on pushes and pull requests.
- Set test profile optimization to level 2 so the 150,000-update Rust test has sufficient margin under the 1,000 ms maximum lease.

## Tests executed in this environment

The available environment has g++ 14.2.0 but does not have `cargo` or `rustc`. An attempt to install them through apt timed out. Therefore, the Rust test module and Cargo executable build have **not** been executed locally. The test script correctly detects the missing toolchain and exits with code 127 rather than pretending that the Rust stack passed.

The C++ native implementation and regression tests were compiled locally with:

```bash
g++ -std=c++17 -O2 -pthread -Wall -Wextra -Werror ...
```

### Native C++ stress result

```text
lease_test cpp_acquire=0 rust_while_cpp_held=-1 cpp_read_with_lease=0 cpp_read_after_expiry=-1 rust_after_expiry=0
common_heavy threads=10 loops_each=30000 completed=300000 errors=0 elapsed_ms=182 ops_per_sec=1648351 expected_updates=300000 observed_value=300000 exact_match=PASS
common_light threads=2 writes=100 errors=0 elapsed_ms=9
cpp_pool_heavy threads=8 ops=400000 errors=0 elapsed_ms=37 ops_per_sec=10810810
cpp_pool_light writes=100 errors=0 elapsed_ms=0
cpp_local_heavy threads=5 ops=100000 errors=0
overall=PASS
```

### Native lease-deadline result

```text
first=0 waiter_rc=0 elapsed_ms=120 lease_ms=120 timeout_ms=500 result=PASS
```

### Atomic update semantics result

```text
empty_increment=PASS type_mismatch_rc=-4 overflow_rc=-5 overflow_value_unchanged=PASS result=PASS
```

All C++ project translation units (`physics.cpp`, `opencl_module.cpp`, `module_bridge.cpp`, `cpp_module_manager.cpp`, `shared_memory.cpp`) also compiled individually with `-Wall -Wextra -Werror`.

## Required final verification

On a machine with stable Rust/Cargo, a C++17 compiler, and the Linux development packages listed in `README.md`, run from the project root:

```bash
cargo clean
bash scripts/test_full_stack.sh
```

The script must finish with `FULL STACK TEST SUITE: PASS`. This will verify the real Rust wrapper, Rust worker threads, native C++ linkage, and C++ thread stress tests together. Until that command has run successfully, the full Rust + C++ stack should be considered **implemented but not locally verified**.

## Concurrency model note

The common table intentionally grants access exclusively by language: Rust and C++ cannot hold leases simultaneously, while multiple modules of the same language may hold leases concurrently. Therefore the cross-language test verifies handoff at lease expiry; atomic updates are tested with concurrent threads within one language cohort. It is not an inter-process shared-memory test.
