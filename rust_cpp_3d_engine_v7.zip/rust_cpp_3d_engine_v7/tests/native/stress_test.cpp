#include "shared_memory.h"
#include "module_bridge.h"
#include <atomic>
#include <chrono>
#include <cstring>
#include <iostream>
#include <thread>
#include <vector>
#include <string>
#include <algorithm>
using Clock=std::chrono::steady_clock;
struct Result { std::atomic<unsigned long long> ops{0}, failures{0}; };
static EngineSharedValue i64v(long long n){EngineSharedValue v{};v.type=ENGINE_VALUE_I64;v.i64=n;return v;}
static long long get_i64(const EngineSharedValue& v){return v.i64;}
int main(){
  bool failed = false;
  // Test 1: lease exclusivity between languages and expiry behavior.
  int a=engine_shared_acquire(ENGINE_LANG_CPP,0,10,80);
  int blocked=engine_shared_acquire(ENGINE_LANG_RUST,0,15,50);
  int own_read=0; EngineSharedValue tmp{};
  if(a==0) own_read=engine_shared_read(ENGINE_LANG_CPP,0,20,&tmp);
  std::this_thread::sleep_for(std::chrono::milliseconds(90));
  int expired_read=engine_shared_read(ENGINE_LANG_CPP,0,20,&tmp);
  int after_expiry=engine_shared_acquire(ENGINE_LANG_RUST,0,20,50);
  if(after_expiry==0) engine_shared_release(ENGINE_LANG_RUST,0);
  std::cout<<"lease_test cpp_acquire="<<a<<" rust_while_cpp_held="<<blocked<<" cpp_read_with_lease="<<own_read<<" cpp_read_after_expiry="<<expired_read<<" rust_after_expiry="<<after_expiry<<"\n";
  if (a != 0 || blocked != -1 || own_read != 0 || expired_read != -1 || after_expiry != 0) failed = true;

  // Test 2: heavy common-table increments by 5 simulated Rust + 5 C++ module threads.
  // Each module uses a unique module id per language, but intentionally shares slot 20.
  constexpr int threads=10, loops=30000;
  EngineSharedValue zero=i64v(0);
  if(engine_shared_acquire(ENGINE_LANG_CPP,0,100,1000)==0){engine_shared_write(ENGINE_LANG_CPP,0,20,&zero);engine_shared_release(ENGINE_LANG_CPP,0);}
  std::atomic<unsigned long long> completed{0}, errors{0};
  auto start=Clock::now();
  std::vector<std::thread> ts;
  for(int t=0;t<threads;t++) ts.emplace_back([&,t]{
    uint32_t lang=t<5?ENGINE_LANG_RUST:ENGINE_LANG_CPP;
    uint32_t id=t%5;
    for(int i=0;i<loops;i++){
      int rc=engine_shared_acquire(lang,id,200,1000);
      if(rc!=0){errors++;continue;}
      EngineSharedValue updated{};
      rc=engine_shared_update(lang,id,20,1,&updated);
      if(rc!=0) errors++; else completed++;
      int rr=engine_shared_release(lang,id); if(rr!=0) errors++;
    }
  });
  for(auto& t:ts)t.join();
  auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count();
  int final_acq=engine_shared_acquire(ENGINE_LANG_CPP,0,100,1000); EngineSharedValue finalv{};
  if(final_acq==0){engine_shared_read(ENGINE_LANG_CPP,0,20,&finalv);engine_shared_release(ENGINE_LANG_CPP,0);}
  std::cout<<"common_heavy threads="<<threads<<" loops_each="<<loops<<" completed="<<completed<<" errors="<<errors<<" elapsed_ms="<<ms<<" ops_per_sec="<<(ms?completed.load()*1000/ms:0)<<" expected_updates="<<(threads*loops)<<" observed_value="<<get_i64(finalv)<<" exact_match="<<(get_i64(finalv)==threads*loops?"PASS":"FAIL")<<"\n";
  if (errors.load() != 0 || completed.load() != threads * loops || get_i64(finalv) != threads * loops) failed = true;

  // Test 3: light common table workload: alternating language writers, 100 total updates.
  errors=0; completed=0; ts.clear();
  start=Clock::now();
  for(int t=0;t<2;t++) ts.emplace_back([&,t]{
    uint32_t lang=t?ENGINE_LANG_CPP:ENGINE_LANG_RUST;
    for(int i=0;i<50;i++){
      if(engine_shared_acquire(lang,0,100,1000)!=0){errors++;continue;}
      auto v=i64v((long long)(t*100+i));
      if(engine_shared_write(lang,0,20,&v)==0) completed++; else errors++;
      if(engine_shared_release(lang,0)!=0) errors++;
      std::this_thread::sleep_for(std::chrono::microseconds(100));
    }
  });
  for(auto& t:ts)t.join();
  auto lightms=std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count();
  std::cout<<"common_light threads=2 writes="<<completed<<" errors="<<errors<<" elapsed_ms="<<lightms<<"\n";
  if (errors.load() != 0 || completed.load() != 100) failed = true;

  // Test 4: C++ private pool under heavy and light load.
  errors=0; completed=0; ts.clear(); start=Clock::now();
  for(int t=0;t<8;t++) ts.emplace_back([&,t]{for(int i=0;i<50000;i++){
    auto v=i64v(((long long)t<<32)|i); int rc=engine_cpp_pool_set((uint32_t)t,&v); EngineSharedValue out{};
    if(rc || engine_cpp_pool_get((uint32_t)t,&out) || get_i64(out)!=get_i64(v)) errors++; else completed++;
  }});
  for(auto& t:ts) t.join();
  ms=std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count();
  std::cout<<"cpp_pool_heavy threads=8 ops="<<completed<<" errors="<<errors<<" elapsed_ms="<<ms<<" ops_per_sec="<<(ms?completed.load()*1000/ms:0)<<"\n";
  if (errors.load() != 0 || completed.load() != 400000) failed = true;
  errors=0; completed=0; start=Clock::now();
  for(int i=0;i<100;i++){auto v=i64v(i);if(engine_cpp_pool_set(0,&v)==0)completed++;else errors++;}
  lightms=std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count();
  std::cout<<"cpp_pool_light writes="<<completed<<" errors="<<errors<<" elapsed_ms="<<lightms<<"\n";
  if (errors.load() != 0 || completed.load() != 100) failed = true;

  // Test 5: C++ per-module private pools, all five modules under parallel load.
  errors=0; completed=0; ts.clear();
  for(int t=0;t<5;t++)ts.emplace_back([&,t]{for(int i=0;i<20000;i++){auto v=i64v(i+t*100000);if(engine_cpp_local_set(t,0,&v)==0){EngineSharedValue o{};if(engine_cpp_local_get(t,0,&o)==0&&get_i64(o)==get_i64(v))completed++;else errors++;}else errors++;}});
  for(auto& t:ts)t.join();
  std::cout<<"cpp_local_heavy threads=5 ops="<<completed<<" errors="<<errors<<"\n";
  if (errors.load() != 0 || completed.load() != 100000) failed = true;
  std::cout << "overall=" << (failed ? "FAIL" : "PASS") << "\n";
  return failed ? 1 : 0;
}
