#include "shared_memory.h"
#include <atomic>
#include <chrono>
#include <iostream>
#include <thread>
using C=std::chrono::steady_clock;
int main(){
 const int first=engine_shared_acquire(ENGINE_LANG_CPP,0,10,120);
 std::atomic<int> result{999};
 std::atomic<long long> elapsed{0};
 const auto start=C::now();
 std::thread waiter([&]{
  const int rc=engine_shared_acquire(ENGINE_LANG_RUST,0,500,100);
  elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(C::now()-start).count();
  result=rc;
  if(rc==0)engine_shared_release(ENGINE_LANG_RUST,0);
 });
 waiter.join();
 std::cout<<"first="<<first<<" waiter_rc="<<result.load()<<" elapsed_ms="<<elapsed.load()<<" lease_ms=120 timeout_ms=500";
 const bool pass=first==0&&result.load()==0&&elapsed.load()>=80&&elapsed.load()<300;
 std::cout<<" result="<<(pass?"PASS":"FAIL")<<"\n";
 return pass?0:1;
}
