#include "../../cpp/module_protocol.h"
#include <cstdio>
#include <cstring>
#include <string>
#if defined(_WIN32)
#include <windows.h>
using Lib = HMODULE;
static Lib open_lib(const char* p) { return LoadLibraryA(p); }
static void* get_sym(Lib h, const char* n) { return reinterpret_cast<void*>(GetProcAddress(h, n)); }
static void close_lib(Lib h) { if (h) FreeLibrary(h); }
#else
#include <dlfcn.h>
using Lib = void*;
static Lib open_lib(const char* p) { return dlopen(p, RTLD_NOW); }
static void* get_sym(Lib h, const char* n) { return dlsym(h, n); }
static void close_lib(Lib h) { if (h) dlclose(h); }
#endif
using HandshakeFn = std::int32_t (*)(std::uint64_t, EngineHandshakeResponseV2*);
using InitFn = std::int32_t (*)(std::uint32_t);
using ExchangeFn = std::int32_t (*)(const std::uint8_t*, std::uint32_t, std::uint8_t*, std::uint32_t, std::uint32_t*);
using ShutdownFn = void (*)();
template<class T> static T sym(Lib h, const char* n) { return reinterpret_cast<T>(get_sym(h, n)); }
struct Plugin { Lib lib{}; HandshakeFn handshake{}; InitFn init{}; ExchangeFn exchange{}; ShutdownFn shutdown{}; std::uint8_t profile{}; std::uint32_t bytes{}; };
static bool load_plugin(const std::string& path, std::uint32_t slot, Plugin& p) {
    p.lib = open_lib(path.c_str()); if (!p.lib) return false;
    p.handshake = sym<HandshakeFn>(p.lib, "cpp_model_handshake"); p.init = sym<InitFn>(p.lib, "cpp_model_init");
    p.exchange = sym<ExchangeFn>(p.lib, "cpp_model_exchange"); p.shutdown = sym<ShutdownFn>(p.lib, "cpp_model_shutdown");
    if (!p.handshake || !p.init || !p.exchange || !p.shutdown) return false;
    const auto hello = std::uint64_t(ENGINE_HS_MAGIC) | (std::uint64_t(ENGINE_HS_VERSION) << 16) |
        (std::uint64_t(ENGINE_LANG_CPP) << 24) | (std::uint64_t(slot) << 28) | (std::uint64_t(ENGINE_PROFILE_128) << 36);
    EngineHandshakeResponseV2 response{}; if (p.handshake(hello, &response) != 0) return false;
    p.profile = static_cast<std::uint8_t>((response.word0 >> 34) & 0x3u);
    p.bytes = static_cast<std::uint32_t>((response.word0 >> 44) & 0xFFu);
    return p.init(slot) == 0 && (p.profile == ENGINE_PROFILE_64 || p.profile == ENGINE_PROFILE_128) && p.bytes == (p.profile == ENGINE_PROFILE_64 ? 8u : 16u);
}
static bool bridge_pair(const std::string& root, std::uint32_t a, std::uint32_t b, std::uint8_t expected_profile) {
#if defined(_WIN32)
    const auto ext = ".dll"; const auto sep = "\\";
#else
    const auto ext = ".so"; const auto sep = "/";
#endif
    Plugin first{}, second{};
    const bool loaded = load_plugin(root + sep + "models " + std::to_string(a) + ext, a, first) &&
        load_plugin(root + sep + "models " + std::to_string(b) + ext, b, second);
    if (!loaded || first.profile != expected_profile || second.profile != expected_profile || first.bytes != second.bytes) {
        if (first.shutdown) first.shutdown();
        if (second.shutdown) second.shutdown();
        close_lib(first.lib); close_lib(second.lib); return false;
    }
    std::uint8_t seed[16]{}; std::uint8_t middle[16]{}; std::uint8_t final_packet[16]{}; std::uint32_t n1=0, n2=0;
    bool ok = first.exchange(seed, first.bytes, middle, sizeof(middle), &n1) == 0 && n1 == first.bytes &&
        second.exchange(middle, n1, final_packet, sizeof(final_packet), &n2) == 0 && n2 == second.bytes;
    if (ok && expected_profile == ENGINE_PROFILE_64) {
        std::uint64_t word=0; std::memcpy(&word, final_packet, 8); ok = ((word >> 56) & 0xFFu) == b;
    } else if (ok) {
        std::uint64_t word=0; std::memcpy(&word, final_packet, 8); ok = ((word >> 48) & 0xFFu) == b;
    }
    first.shutdown(); second.shutdown(); close_lib(first.lib); close_lib(second.lib); return ok;
}
int main(int argc, char** argv) {
    if (argc != 2) { std::fprintf(stderr, "usage: direct_bridge_test <modules/cpp directory>\n"); return 2; }
    const std::string root = argv[1];
    if (!bridge_pair(root, 0, 2, ENGINE_PROFILE_64) || !bridge_pair(root, 1, 3, ENGINE_PROFILE_128)) {
        std::fprintf(stderr, "same-language direct packet bridge failed\n"); return 10;
    }
    std::puts("cpp_same_language_direct_bridge profile64=PASS profile128=PASS cross-language-isolation=BY-runtime-route-key");
    return 0;
}
