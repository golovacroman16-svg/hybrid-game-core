#include "../../cpp/module_protocol.h"
#include <cstdio>
#include <string>
#if defined(_WIN32)
#include <windows.h>
using Lib = HMODULE;
static Lib open_lib(const char* p) { return LoadLibraryA(p); }
static void* get_sym(Lib h, const char* n) { return reinterpret_cast<void*>(GetProcAddress(h, n)); }
static void close_lib(Lib h) { if (h) FreeLibrary(h); }
#else
#include <dlfcn.h>
using Lib = void*;
static Lib open_lib(const char* p) { return dlopen(p, RTLD_NOW); }
static void* get_sym(Lib h, const char* n) { return dlsym(h, n); }
static void close_lib(Lib h) { if (h) dlclose(h); }
#endif
using VersionFn = std::uint32_t (*)();
using HandshakeFn = std::int32_t (*)(std::uint64_t, EngineHandshakeResponseV2*);
using InitFn = std::int32_t (*)(std::uint32_t);
using ExchangeFn = std::int32_t (*)(const std::uint8_t*, std::uint32_t, std::uint8_t*, std::uint32_t, std::uint32_t*);
using HealthFn = std::int32_t (*)();
using ShutdownFn = void (*)();
template<class T> static T sym(Lib h, const char* n) { return reinterpret_cast<T>(get_sym(h, n)); }
int main(int argc, char** argv) {
    if (argc != 2) { std::fprintf(stderr, "usage: module_plugin_test <modules/cpp directory>\n"); return 2; }
    for (std::uint32_t i = 0; i < 11; ++i) {
#if defined(_WIN32)
        const std::string path = std::string(argv[1]) + "\\models " + std::to_string(i) + ".dll";
#else
        const std::string path = std::string(argv[1]) + "/models " + std::to_string(i) + ".so";
#endif
        Lib lib = open_lib(path.c_str());
        if (!lib) { std::fprintf(stderr, "load failed: %s\n", path.c_str()); return 10; }
        auto version = sym<VersionFn>(lib, "cpp_model_protocol_version");
        auto handshake = sym<HandshakeFn>(lib, "cpp_model_handshake");
        auto init = sym<InitFn>(lib, "cpp_model_init");
        auto exchange = sym<ExchangeFn>(lib, "cpp_model_exchange");
        auto health = sym<HealthFn>(lib, "cpp_model_health");
        auto shutdown = sym<ShutdownFn>(lib, "cpp_model_shutdown");
        EngineHandshakeResponseV2 response{};
        const std::uint64_t hello = ENGINE_HS_MAGIC | (std::uint64_t(ENGINE_HS_VERSION) << 16) |
            (std::uint64_t(ENGINE_LANG_CPP) << 24) | (std::uint64_t(i) << 28) | (std::uint64_t(ENGINE_PROFILE_128) << 36);
        if (!version || !handshake || !init || !exchange || !health || !shutdown ||
            version() != ENGINE_CPP_MODEL_PROTOCOL_VERSION || handshake(hello, &response) != 0) {
            std::fprintf(stderr, "symbol/version/handshake failed for slot %u\n", i); close_lib(lib); return 11;
        }
        const auto profile = static_cast<std::uint8_t>((response.word0 >> 34) & 0x3u);
        const auto negotiated_size = static_cast<std::uint32_t>((response.word0 >> 44) & 0xFFu);
        const auto response_magic = static_cast<std::uint16_t>(response.word0 & 0xFFFFu);
        const auto response_version = static_cast<std::uint8_t>((response.word0 >> 16) & 0xFFu);
        const auto response_language = static_cast<std::uint8_t>((response.word0 >> 32) & 0x3u);
        const auto response_slot = static_cast<std::uint8_t>((response.word0 >> 36) & 0xFFu);
        if (response_magic != ENGINE_HS_MAGIC || response_version != ENGINE_HS_VERSION || response_language != ENGINE_LANG_CPP || response_slot != i ||
            (profile != ENGINE_PROFILE_64 && profile != ENGINE_PROFILE_128) || negotiated_size != (profile == ENGINE_PROFILE_64 ? 8u : 16u)) {
            std::fprintf(stderr, "bad negotiated profile for slot %u\n", i); close_lib(lib); return 12;
        }
        if (init(i) != 0 || health() <= 0) { std::fprintf(stderr, "init/health failed for slot %u\n", i); close_lib(lib); return 13; }
        std::uint8_t input[16]{}; std::uint8_t output[16]{}; std::uint32_t output_size = 0;
        const auto input_size = negotiated_size;
        if (exchange(input, input_size, output, sizeof(output), &output_size) != 0 || output_size != negotiated_size) {
            std::fprintf(stderr, "exchange failed for slot %u\n", i); shutdown(); close_lib(lib); return 14;
        }
        shutdown(); close_lib(lib);
    }
    std::puts("cpp_dynamic_modules=11 handshake64_to128=PASS negotiated_64_128=PASS init=PASS health=PASS exchange=PASS");
    return 0;
}
