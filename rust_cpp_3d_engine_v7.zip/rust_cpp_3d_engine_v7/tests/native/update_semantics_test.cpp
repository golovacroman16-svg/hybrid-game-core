#include "shared_memory.h"
#include <cstdint>
#include <iostream>
#include <limits>

static EngineSharedValue i64v(int64_t n) {
    EngineSharedValue value{};
    value.type = ENGINE_VALUE_I64;
    value.i64 = n;
    return value;
}

int main() {
    if (engine_shared_acquire(ENGINE_LANG_CPP, 0, 20, 500) != 0) return 1;
    EngineSharedValue result{};
    const int empty_rc = engine_shared_update(ENGINE_LANG_CPP, 0, 20, 7, &result);
    const bool empty_ok = empty_rc == 0 && result.type == ENGINE_VALUE_I64 && result.i64 == 7;

    EngineSharedValue f64{};
    f64.type = ENGINE_VALUE_F64;
    f64.f64 = 1.5;
    engine_shared_write(ENGINE_LANG_CPP, 0, 20, &f64);
    const int type_rc = engine_shared_update(ENGINE_LANG_CPP, 0, 20, 1, &result);

    EngineSharedValue maxv = i64v(std::numeric_limits<int64_t>::max());
    engine_shared_write(ENGINE_LANG_CPP, 0, 20, &maxv);
    const int overflow_rc = engine_shared_update(ENGINE_LANG_CPP, 0, 20, 1, &result);
    EngineSharedValue after{};
    engine_shared_read(ENGINE_LANG_CPP, 0, 20, &after);
    const bool overflow_unchanged = after.type == ENGINE_VALUE_I64 && after.i64 == std::numeric_limits<int64_t>::max();
    engine_shared_release(ENGINE_LANG_CPP, 0);

    const bool pass = empty_ok && type_rc == -4 && overflow_rc == -5 && overflow_unchanged;
    std::cout << "empty_increment=" << (empty_ok ? "PASS" : "FAIL")
              << " type_mismatch_rc=" << type_rc
              << " overflow_rc=" << overflow_rc
              << " overflow_value_unchanged=" << (overflow_unchanged ? "PASS" : "FAIL")
              << " result=" << (pass ? "PASS" : "FAIL") << '\n';
    return pass ? 0 : 1;
}
