fn main() {
 cc::Build::new().cpp(true).file("cpp/physics.cpp").file("cpp/opencl_module.cpp").file("cpp/module_bridge.cpp").file("cpp/cpp_module_manager.cpp").file("cpp/shared_memory.cpp").include("cpp").flag_if_supported("-std=c++17").warnings(true).compile("engine_cpp_modules");
 #[cfg(target_os="linux")] println!("cargo:rustc-link-lib=dl");
 for f in ["cpp/physics.cpp","cpp/physics.h","cpp/opencl_module.cpp","cpp/opencl_module.h","cpp/module_bridge.cpp","cpp/module_bridge.h","cpp/cpp_module_manager.cpp","cpp/cpp_module_manager.h","cpp/shared_memory.cpp","cpp/shared_memory.h","cpp/module_protocol.h"] { println!("cargo:rerun-if-changed={f}"); }
}
