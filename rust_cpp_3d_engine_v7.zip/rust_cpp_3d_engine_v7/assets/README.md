Put models, textures, audio, shader sources, and material definitions into the matching subdirectories. Asset loading is not implemented yet.
