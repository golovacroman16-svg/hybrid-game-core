# Modular 3D engine scaffold — Rust + C++

A modular 3D-engine scaffold with a C ABI bridge, startup asset discovery, 21-region cross-language shared table, language-private pools, and per-module local pools.

## Shared state and memory pools

Implemented in `src/shared_state.rs` and `cpp/shared_memory.{h,cpp}`.

- **Common table:** 21 fixed regions indexed `0..20`; names below.
- **Language-exclusive access:** Rust and C++ cannot hold leases simultaneously. Up to 5 distinct module IDs per language can hold simultaneous leases from the same language. A competing language waits no longer than `timeout_ms`.
- **Time limits:** lease duration `1..=1000 ms`; expired leases are invalidated on the next acquire/table operation. Release promptly after access.
- **Shared types:** `I64`, `F64`, `Bool`, `Vec3`, and UTF-8 `Text` up to 127 bytes. The boundary uses a C-compatible fixed-layout struct, not native Rust/C++ strings or containers.
- **C++-only pool:** 64 entries; **Rust-only pool:** 64 entries. Rust's pool is not exported through the C ABI.
- **Per-module local pools:** 32 entries for each module ID `0..4` per language. They do not cross the language boundary.
- **Synchronization:** native mutex protects common/C++ pools; Rust `RwLock`/`Mutex` protects Rust pools. No pointer to an internal pool entry is returned. `engine_shared_update` / Rust `SharedAccess::update_i64` performs a signed 64-bit increment/decrement as one atomic read-modify-write under the same mutex. Empty cells start at zero; other types are rejected; overflow is checked.
- **Lease waiting:** competing-language waiters sleep until the earlier of their own timeout or the nearest conflicting lease deadline; explicit release notifies waiting threads immediately.

### Common-table slot map

| ID | Name | Suggested type/meaning |
|---:|---|---|
| 0 | `simulation_time` | `F64`, elapsed simulation seconds |
| 1 | `delta_time` | `F64`, frame delta |
| 2 | `player_position` | `Vec3` |
| 3 | `player_velocity` | `Vec3` |
| 4 | `input_mask` | `I64`, packed input flags |
| 5 | `world_seed` | `I64` |
| 6 | `active_scene` | `Text` or `I64` scene ID |
| 7 | `physics_tick` | `I64` |
| 8 | `frame_index` | `I64` |
| 9 | `entity_count` | `I64` |
| 10 | `camera_position` | `Vec3` |
| 11 | `camera_direction` | `Vec3` |
| 12 | `gravity` | `Vec3` |
| 13 | `collision_count` | `I64` |
| 14 | `audio_state` | `I64` enum |
| 15 | `render_state` | `I64` enum |
| 16 | `asset_generation` | `I64` |
| 17 | `game_state` | `I64` enum |
| 18 | `debug_flags` | `I64` bitmask |
| 19 | `network_tick` | `I64` |
| 20 | `user_scalar` | `F64`, application-defined |

Slot meanings are conventions; enforce one agreed type per slot in engine code.

### Rust usage

```rust
let table = shared_state::SharedAccess::new(0)?;
table.acquire(20, 100)?; // wait up to 20 ms; lease for 100 ms
 table.write(2, shared_state::SharedValue::Vec3([1.0, 2.0, 3.0]))?;
let position = table.read(2)?;
let tick = table.update_i64(7, 1)?; // atomic increment; keep lease held
table.release()?;
shared_state::rust_pool_set(0, shared_state::SharedValue::Text("rust-only".into()))?;
shared_state::rust_local_set(0, 0, shared_state::SharedValue::I64(123))?;
```

### C++ usage

```cpp
#include "shared_memory.h"
EngineSharedValue value{};
value.type = ENGINE_VALUE_VEC3;
value.vec3[0] = 1.0; value.vec3[1] = 2.0; value.vec3[2] = 3.0;
if (engine_shared_acquire(ENGINE_LANG_CPP, 0, 20, 100) == 0) {
    engine_shared_write(ENGINE_LANG_CPP, 0, 2, &value);
    EngineSharedValue updated{};
    engine_shared_update(ENGINE_LANG_CPP, 0, 7, 1, &updated); // atomic increment
    engine_shared_release(ENGINE_LANG_CPP, 0);
}
```

## Build

Prerequisites: Rust stable/Cargo, C++17 compiler, and system dependencies required by `winit`.

```bash
cargo run
```

The OpenCL module may report no compatible runtime/device; that is independent of the shared-state table.

## Limits

- In-process state only, not OS shared memory across separate processes.
- Lease limits are logical time bounds, not real-time scheduling guarantees.
- Expired lease operations fail until the module reacquires access. Use cleanup paths to release leases.

## Full Rust + C++ build and threaded tests

The shared-state unit tests exercise the actual Rust wrapper and the native C++ implementation in the same Cargo test process. They include five real Rust threads performing 150,000 atomic increments through FFI, five Rust threads exercising the Rust-only `RwLock`/`Mutex` pools, ABI layout validation, and a Rust waiter calling the C++-language lease API to verify wake-up at a Rust lease deadline.

### Linux (Debian/Ubuntu)

Install a stable Rust toolchain using [rustup](https://rustup.rs/) and install the native build dependencies:

```bash
sudo apt-get update
sudo apt-get install -y build-essential pkg-config libxkbcommon-dev libwayland-dev libx11-dev libxrandr-dev libxi-dev libxcursor-dev libxinerama-dev libxkbcommon-x11-dev libegl1-mesa-dev libudev-dev
rustup toolchain install stable
rustup default stable
rustc --version
cargo --version
```

From the project root (`rust_cpp_3d_engine_v5/`):

```bash
cargo clean
bash scripts/test_full_stack.sh
```

The script runs Rust unit tests without opening a window, builds the executable, then compiles and runs the standalone native C++ stress tests. The Rust tests link the C++ sources through `build.rs`. `cargo run` launches the graphical window and therefore requires a working desktop/session.

### Windows (MSVC)

Install Rust stable with rustup and Visual Studio Build Tools with the **Desktop development with C++** workload. In a *Developer PowerShell for VS*, run:

```powershell
rustup toolchain install stable
rustup default stable
rustc --version
cargo --version
cargo clean
$env:ENGINE_TEST_PLUGIN_DIR = (Resolve-Path .\modules).Path
cargo test --bin rust_cpp_3d_engine -- --nocapture
cargo build --bin rust_cpp_3d_engine
Remove-Item Env:ENGINE_TEST_PLUGIN_DIR
```

### macOS

Install Xcode Command Line Tools (`xcode-select --install`), then install Rust stable via rustup and run the same Cargo commands from the project root.

### What the tests prove (and do not prove)

- `rust_threads_atomic_increment_shared_cpp_table`: five actual Rust OS threads each call the C ABI into C++ for 30,000 increments; the final value must be exactly 150,000.
- `rust_private_pools_are_thread_safe_under_load`: five actual Rust threads concurrently exercise the Rust-only shared and per-module pools.
- `cpp_waiter_wakes_at_rust_lease_deadline`: a Rust thread calls the C++ lease API using the C++ language ID while a Rust lease is active; it must acquire close to the 250 ms lease expiry, not the 500 ms caller timeout.
- `rust_ffi_layout_matches_native_value`: checks the Rust representation's expected 176-byte C ABI layout. Native C++ compilation and linking are exercised by Cargo's build script.

The same commands are available on Windows in a Developer PowerShell by invoking the Cargo test/build commands directly; the Bash test script is intended for Linux/macOS. These are in-process integration tests, not inter-process shared memory tests. The lease policy intentionally prevents Rust and C++ from owning the common table simultaneously; cross-language tests therefore verify arbitration and handoff rather than simultaneous cross-language writes.

## External module slots (v7 — negotiated handshake and direct bridge)

The core reserves **21 stable module slots** at startup. The exact Windows paths are:

- C++: `modules/cpp/models 0.dll` through `modules/cpp/models 10.dll` (11 slots).
- Rust: `modules/rust/models 0.dll` through `modules/rust/models 9.dll` (10 slots).

On Linux, the same stems use `.so` (`models 0.so`, etc.); on macOS they use `.dylib`. The loader checks the native extension first and also accepts `.dll` as a filename on Linux/macOS if the file is a valid native library for that platform. A Windows DLL cannot be loaded on Linux merely by renaming it.

### Automatic discovery and core fallback

At startup `module_runtime::ModuleManager::discover("modules")` checks every expected slot. A missing file, invalid library, missing required export, protocol-version mismatch, failed initialization, or failed health check leaves the slot occupied by a core-owned stub. The same slot is quarantined and replaced with a stub if a later health/update call fails. Other modules continue updating. A native crash or a module that never returns cannot be caught safely inside the same process; use process isolation for untrusted modules.

### Language-specific handshake protocols v2

Rust and C++ each have their own handshake entry point and symbol namespace. The first request is exactly **64 bits**; the module replies with a **128-bit** response. The response confirms language, protocol version, slot, packet profile, input/output sizes, capabilities, direct-bridge group, and module ID. The loader rejects language/slot/profile mismatches and keeps the slot occupied by a core stub.

Required Rust exports:

- `rust_model_handshake(hello: u64, response: *mut u64) -> i32`
- `rust_model_protocol_version() -> u32` (must return `2`)
- `rust_model_init(slot: u32) -> i32`
- `rust_model_exchange(input, input_size, output, output_capacity, output_size) -> i32`
- `rust_model_health() -> i32` (positive means healthy)
- `rust_model_shutdown()`

C++ exports use the corresponding `cpp_model_` prefix: `cpp_model_handshake`, `cpp_model_protocol_version`, `cpp_model_init`, `cpp_model_exchange`, `cpp_model_health`, and `cpp_model_shutdown`. The ABI is specified in `cpp/module_protocol.h`; the Rust host and module implementation are in `src/module_runtime.rs` and `plugins/rust/model_template.rs`.

The handshake response negotiates one of two packet formats: **profile 64** (8-byte input/output packets) or **profile 128** (16-byte input/output packets). All subsequent exchanges must use the exact negotiated size; mismatches quarantine the module and activate its core stub. The example modules deliberately choose profile 64 for even-numbered slots and profile 128 for odd-numbered slots to exercise both paths.

### Same-language direct bridge

A module announces `bridge_group` in its first 128-bit handshake response. The runtime forwards a module's raw output packet directly as the next input only when **language, bridge group, and negotiated profile all match**. Rust routes and C++ routes are separate; Rust data can never be delivered to a C++ module through this bridge. A bridge group of `0` disables bridging for that module. The first module in each compatible route receives a core-generated seed packet. The sample templates use group `1`.

The direct bridge forwards opaque bytes and does not reinterpret the packet between modules. Therefore modules in a shared bridge group must agree on the packet's application-level meaning in addition to matching its negotiated size. Use a new bridge group or profile when formats differ.

### Build example plug-ins

Linux (stable Rust toolchain and g++):

```bash
bash scripts/build_example_plugins.sh
bash scripts/test_full_stack.sh
```

Windows (Visual Studio Developer PowerShell and stable Rust):

```powershell
.\scripts\build_example_plugins.ps1
$env:ENGINE_TEST_PLUGIN_DIR = (Resolve-Path .\modules).Path
cargo test --bin rust_cpp_3d_engine -- --nocapture
cargo build --bin rust_cpp_3d_engine
Remove-Item Env:ENGINE_TEST_PLUGIN_DIR
```

The Linux full-stack script builds all 21 example shared libraries, runs Rust tests that load them through the real dynamic loader, verifies the all-missing and corrupt-module fallback paths, and runs native C++ ABI/stress tests. Build outputs are intentionally not checked into source control; the core fallback works when the `modules` directory is empty.
