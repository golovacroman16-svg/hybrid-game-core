#pragma once
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int32_t ocl12_is_available(void);
int32_t ocl12_get_device_name(char* output, size_t capacity);
int32_t ocl12_vector_add(const float* a, const float* b, float* output, size_t count);
const char* ocl12_last_error(void);
#ifdef __cplusplus
}
#endif
