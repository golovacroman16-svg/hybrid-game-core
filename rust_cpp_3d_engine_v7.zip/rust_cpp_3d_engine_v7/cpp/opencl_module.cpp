#include "opencl_module.h"
#include <algorithm>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#ifdef _WIN32
#include <windows.h>
using Lib=HMODULE;
static Lib open_lib(){return LoadLibraryA("OpenCL.dll");}
static void* sym(Lib h,const char*n){return reinterpret_cast<void*>(GetProcAddress(h,n));}
#else
#include <dlfcn.h>
using Lib=void*;
static Lib open_lib(){
#ifdef __APPLE__
 Lib h=dlopen("/System/Library/Frameworks/OpenCL.framework/OpenCL",RTLD_NOW|RTLD_LOCAL); if(!h)h=dlopen("libOpenCL.dylib",RTLD_NOW|RTLD_LOCAL); return h;
#else
 Lib h=dlopen("libOpenCL.so.1",RTLD_NOW|RTLD_LOCAL); if(!h)h=dlopen("libOpenCL.so",RTLD_NOW|RTLD_LOCAL); return h;
#endif
}
static void* sym(Lib h,const char*n){return dlsym(h,n);}
#endif
namespace {
using I=int32_t; using U=uint32_t; using B=uint64_t; using D=B; using M=B; using P=intptr_t; using Q=B;
struct _plat;using Plat=_plat*;struct _dev;using Dev=_dev*;struct _ctx;using Ctx=_ctx*;struct _queue;using Queue=_queue*;struct _mem;using Mem=_mem*;struct _prog;using Prog=_prog*;struct _kernel;using Kernel=_kernel*;
constexpr I OK=0; constexpr D ALL=~D(0); constexpr U DEV_NAME=0x102B, BUILD_LOG=0x1183; constexpr M READ=1<<2,WRITE=1<<1,COPY=1<<5; constexpr U TRUE_=1;
std::mutex mu; Lib lib=nullptr; std::string err="OpenCL runtime not initialized", device_name; Dev dev=nullptr;
#define FN(ret,n,args) using n##_t=ret(*)args; n##_t n=nullptr
FN(I,GetPlatforms,(U,Plat*,U*)); FN(I,GetDevices,(Plat,D,U,Dev*,U*)); FN(I,GetDeviceInfo,(Dev,U,size_t,void*,size_t*));
FN(Ctx,CreateContext,(const P*,U,const Dev*,void(*)(const char*,const void*,size_t,void*),void*,I*));
FN(Queue,CreateQueue,(Ctx,Dev,Q,I*)); FN(Prog,CreateSource,(Ctx,U,const char**,const size_t*,I*)); FN(I,Build,(Prog,U,const Dev*,const char*,void(*)(Prog,void*),void*));
FN(I,BuildInfo,(Prog,Dev,U,size_t,void*,size_t*)); FN(Kernel,CreateKernel,(Prog,const char*,I*)); FN(Mem,CreateBuffer,(Ctx,M,size_t,void*,I*)); FN(I,SetArg,(Kernel,U,size_t,const void*));
FN(I,RunKernel,(Queue,Kernel,U,const size_t*,const size_t*,const size_t*,U,const void*,void*)); FN(I,ReadBuffer,(Queue,Mem,U,size_t,size_t,void*,U,const void*,void*)); FN(I,Finish,(Queue));
FN(I,RelMem,(Mem)); FN(I,RelKernel,(Kernel)); FN(I,RelProg,(Prog)); FN(I,RelQueue,(Queue)); FN(I,RelCtx,(Ctx));
#undef FN
template<class T> bool bind(T& f,const char*n){f=reinterpret_cast<T>(sym(lib,n));if(!f){err=std::string("Missing OpenCL symbol: ")+n;return false;}return true;}
bool init(){if(dev)return true;if(!lib)lib=open_lib();if(!lib){err="OpenCL 1.2 runtime/ICD loader not found";return false;}
if(!bind(GetPlatforms,"clGetPlatformIDs"))return false;
 if(!bind(GetDevices,"clGetDeviceIDs"))return false;
 if(!bind(GetDeviceInfo,"clGetDeviceInfo"))return false;
 if(!bind(CreateContext,"clCreateContext"))return false;
 if(!bind(CreateQueue,"clCreateCommandQueue"))return false;
 if(!bind(CreateSource,"clCreateProgramWithSource"))return false;
 if(!bind(Build,"clBuildProgram"))return false;
 if(!bind(BuildInfo,"clGetProgramBuildInfo"))return false;
 if(!bind(CreateKernel,"clCreateKernel"))return false;
 if(!bind(CreateBuffer,"clCreateBuffer"))return false;
 if(!bind(SetArg,"clSetKernelArg"))return false;
 if(!bind(RunKernel,"clEnqueueNDRangeKernel"))return false;
 if(!bind(ReadBuffer,"clEnqueueReadBuffer"))return false;
 if(!bind(Finish,"clFinish"))return false;
 if(!bind(RelMem,"clReleaseMemObject"))return false;
 if(!bind(RelKernel,"clReleaseKernel"))return false;
 if(!bind(RelProg,"clReleaseProgram"))return false;
 if(!bind(RelQueue,"clReleaseCommandQueue"))return false;
 if(!bind(RelCtx,"clReleaseContext"))return false;
 U np=0; if(GetPlatforms(0,nullptr,&np)!=OK||!np){err="No OpenCL platform found";return false;}std::vector<Plat> ps(np);if(GetPlatforms(np,ps.data(),nullptr)!=OK){err="clGetPlatformIDs failed";return false;}
 for(auto p:ps){U nd=0;if(GetDevices(p,ALL,0,nullptr,&nd)!=OK||!nd)continue;std::vector<Dev> ds(nd);if(GetDevices(p,ALL,nd,ds.data(),nullptr)==OK&&!ds.empty()){dev=ds[0];break;}}
 if(!dev){err="No OpenCL device found";return false;}size_t n=0;GetDeviceInfo(dev,DEV_NAME,0,nullptr,&n);if(n){std::vector<char>b(n,0);if(GetDeviceInfo(dev,DEV_NAME,n,b.data(),nullptr)==OK)device_name=b.data();}err.clear();return true;}
}
extern "C" int32_t ocl12_is_available(){std::lock_guard<std::mutex>l(mu);return init()?1:0;}
extern "C" int32_t ocl12_get_device_name(char*out,size_t cap){std::lock_guard<std::mutex>l(mu);if(!init())return -1;if(!out||!cap)return -2;size_t n=std::min(cap-1,device_name.size());memcpy(out,device_name.data(),n);out[n]=0;return (I)n;}
extern "C" const char* ocl12_last_error(){return err.c_str();}
extern "C" int32_t ocl12_vector_add(const float*a,const float*b,float*out,size_t n){std::lock_guard<std::mutex>l(mu);if((!a||!b||!out)&&n)return err="Null vector pointer",-2;if(!n)return 0;if(!init())return -1;
 const char*src="__kernel void vadd(__global const float*a,__global const float*b,__global float*out){size_t i=get_global_id(0);out[i]=a[i]+b[i];}";I rc=0;Ctx c=CreateContext(nullptr,1,&dev,nullptr,nullptr,&rc);if(!c||rc)return err="clCreateContext failed",-3;Queue q=CreateQueue(c,dev,0,&rc);if(!q||rc){RelCtx(c);return err="clCreateCommandQueue failed",-4;}Prog p=CreateSource(c,1,&src,nullptr,&rc);if(!p||rc){RelQueue(q);RelCtx(c);return err="clCreateProgramWithSource failed",-5;}
 rc=Build(p,1,&dev,"-cl-std=CL1.2",nullptr,nullptr);if(rc){size_t sz=0;BuildInfo(p,dev,BUILD_LOG,0,nullptr,&sz);std::vector<char>log(sz+1,0);if(sz)BuildInfo(p,dev,BUILD_LOG,sz,log.data(),nullptr);err=std::string("OpenCL kernel build failed: ")+log.data();RelProg(p);RelQueue(q);RelCtx(c);return -6;}Kernel k=CreateKernel(p,"vadd",&rc);if(!k||rc){RelProg(p);RelQueue(q);RelCtx(c);return err="clCreateKernel failed",-7;}
 size_t bytes=n*sizeof(float);Mem ma=CreateBuffer(c,READ|COPY,bytes,const_cast<float*>(a),&rc);Mem mb=CreateBuffer(c,READ|COPY,bytes,const_cast<float*>(b),&rc);Mem mo=CreateBuffer(c,WRITE,bytes,nullptr,&rc);if(!ma||!mb||!mo||rc){if(ma)RelMem(ma);if(mb)RelMem(mb);if(mo)RelMem(mo);RelKernel(k);RelProg(p);RelQueue(q);RelCtx(c);return err="clCreateBuffer failed",-8;}
 rc=SetArg(k,0,sizeof(Mem),&ma);if(!rc)rc=SetArg(k,1,sizeof(Mem),&mb);if(!rc)rc=SetArg(k,2,sizeof(Mem),&mo);size_t global=n;if(!rc)rc=RunKernel(q,k,1,nullptr,&global,nullptr,0,nullptr,nullptr);if(!rc)rc=ReadBuffer(q,mo,TRUE_,0,bytes,out,0,nullptr,nullptr);if(!rc)rc=Finish(q);
 RelMem(ma);RelMem(mb);RelMem(mo);RelKernel(k);RelProg(p);RelQueue(q);RelCtx(c);if(rc)return err="OpenCL vector_add execution failed",-9;err.clear();return 0;}
