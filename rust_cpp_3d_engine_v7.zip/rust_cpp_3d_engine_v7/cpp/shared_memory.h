#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
enum EngineLanguage : uint32_t { ENGINE_LANG_RUST = 0, ENGINE_LANG_CPP = 1 };
enum EngineValueType : uint32_t { ENGINE_VALUE_EMPTY=0, ENGINE_VALUE_I64=1, ENGINE_VALUE_F64=2, ENGINE_VALUE_BOOL=3, ENGINE_VALUE_VEC3=4, ENGINE_VALUE_TEXT=5 };
typedef struct EngineSharedValue { uint32_t type; int64_t i64; double f64; double vec3[3]; char text[128]; } EngineSharedValue;
int32_t engine_shared_acquire(uint32_t language,uint32_t module_id,uint32_t timeout_ms,uint32_t lease_ms);
int32_t engine_shared_release(uint32_t language,uint32_t module_id);
int32_t engine_shared_read(uint32_t language,uint32_t module_id,uint32_t slot,EngineSharedValue* out_value);
int32_t engine_shared_write(uint32_t language,uint32_t module_id,uint32_t slot,const EngineSharedValue* value);
// Atomic signed 64-bit increment. EMPTY is treated as zero; non-I64 cells are rejected.
int32_t engine_shared_update(uint32_t language,uint32_t module_id,uint32_t slot,int64_t delta,EngineSharedValue* out_value);
uint32_t engine_shared_value_size(void);
const char* engine_shared_slot_name(uint32_t slot);
uint32_t engine_shared_active_count(uint32_t language);
int32_t engine_cpp_pool_set(uint32_t key,const EngineSharedValue* value);
int32_t engine_cpp_pool_get(uint32_t key,EngineSharedValue* out_value);
int32_t engine_cpp_local_set(uint32_t module_id,uint32_t key,const EngineSharedValue* value);
int32_t engine_cpp_local_get(uint32_t module_id,uint32_t key,EngineSharedValue* out_value);
#ifdef __cplusplus
}
#endif
