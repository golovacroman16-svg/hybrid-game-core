#include "module_bridge.h"
#include <array>
#include <cstring>
#include <mutex>
namespace {
constexpr uint32_t RUST_LIMIT=10, CPP_LIMIT=11;
constexpr size_t NAME_SIZE=96;
struct Registry {
 std::array<std::array<char,NAME_SIZE>,RUST_LIMIT> rust{};
 std::array<std::array<char,NAME_SIZE>,CPP_LIMIT> cpp{};
 uint32_t nr=0, nc=0;
 std::mutex mutex;
} r;
}
extern "C" int32_t engine_bridge_register(uint32_t kind,const char* name) {
 if (!name || !*name) return -1;
 size_t n=std::strlen(name); if(n>=NAME_SIZE) return -2;
 std::lock_guard<std::mutex> lock(r.mutex);
 if(kind==0) {
  for(uint32_t i=0;i<r.nr;i++) if(std::strcmp(r.rust[i].data(),name)==0) return -3;
  if(r.nr>=RUST_LIMIT) return -4;
  std::memcpy(r.rust[r.nr].data(),name,n+1); return static_cast<int32_t>(r.nr++);
 }
 if(kind==1) {
  for(uint32_t i=0;i<r.nc;i++) if(std::strcmp(r.cpp[i].data(),name)==0) return -3;
  if(r.nc>=CPP_LIMIT) return -4;
  std::memcpy(r.cpp[r.nc].data(),name,n+1); return static_cast<int32_t>(r.nc++);
 }
 return -5;
}
extern "C" uint32_t engine_bridge_count(uint32_t kind) {
 std::lock_guard<std::mutex> lock(r.mutex);
 return kind==0?r.nr:(kind==1?r.nc:0);
}
extern "C" const char* engine_bridge_name(uint32_t kind,uint32_t i) {
 std::lock_guard<std::mutex> lock(r.mutex);
 if(kind==0 && i<r.nr) return r.rust[i].data();
 if(kind==1 && i<r.nc) return r.cpp[i].data();
 return nullptr;
}
