#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// C ABI: primitive pointers only; no C++ objects cross the language boundary.
// Inputs/outputs are world-space metres and seconds.
void physics_step(
    float* px, float* py, float* pz,
    float* vx, float* vy, float* vz,
    float dt,
    float move_x, float move_z,
    float move_speed,
    float gravity,
    float jump_velocity,
    int jump_pressed
);

#ifdef __cplusplus
}
#endif
