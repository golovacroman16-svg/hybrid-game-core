#include "cpp_module_manager.h"
#include "module_bridge.h"
extern "C" int32_t cpp_manager_register(const char* name) { return engine_bridge_register(1,name); }
extern "C" uint32_t cpp_manager_count(void) { return engine_bridge_count(1); }
extern "C" const char* cpp_manager_name(uint32_t index) { return engine_bridge_name(1,index); }
