#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
// kind 0=Rust (max 10), kind 1=C++ (max 11)
int32_t engine_bridge_register(uint32_t kind, const char* name);
uint32_t engine_bridge_count(uint32_t kind);
const char* engine_bridge_name(uint32_t kind, uint32_t index);
#ifdef __cplusplus
}
#endif
