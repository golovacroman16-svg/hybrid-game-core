#include "physics.h"

#include <algorithm>
#include <cmath>

extern "C" void physics_step(
    float* px, float* py, float* pz,
    float* vx, float* vy, float* vz,
    float dt,
    float move_x, float move_z,
    float move_speed,
    float gravity,
    float jump_velocity,
    int jump_pressed
) {
    if (!px || !py || !pz || !vx || !vy || !vz) return;

    // Defensive clamp: avoid huge simulation steps after a pause/debugger stop.
    dt = std::clamp(dt, 0.0f, 0.05f);

    float mx = move_x;
    float mz = move_z;
    const float len = std::sqrt(mx * mx + mz * mz);
    if (len > 1.0f) {
        mx /= len;
        mz /= len;
    }

    *vx = mx * move_speed;
    *vz = mz * move_speed;

    // Simple floor plane at y = 0. The player origin is treated as feet.
    const bool grounded = (*py <= 0.0001f && *vy <= 0.0f);
    if (jump_pressed && grounded) {
        *vy = jump_velocity;
    } else {
        *vy += gravity * dt;
    }

    *px += *vx * dt;
    *py += *vy * dt;
    *pz += *vz * dt;

    if (*py < 0.0f) {
        *py = 0.0f;
        if (*vy < 0.0f) *vy = 0.0f;
    }
}
