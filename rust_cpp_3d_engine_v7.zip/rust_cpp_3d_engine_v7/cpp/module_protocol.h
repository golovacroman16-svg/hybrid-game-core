#pragma once
#include <cstdint>
#include <cstddef>

// Handshake v2: request is exactly 64 bits, response exactly 128 bits.
// word0 response fields: magic[0:15], version[16:23], status[24:31],
// language[32:33], profile[34:35], slot[36:43], in_size[44:51],
// out_size[52:59], capabilities[60:63]. word1: bridge_group[0:31], module_id[32:63].
constexpr std::uint16_t ENGINE_HS_MAGIC = 0x484D; // "MH" on the wire
constexpr std::uint8_t ENGINE_HS_VERSION = 2;
constexpr std::uint8_t ENGINE_LANG_RUST = 1;
constexpr std::uint8_t ENGINE_LANG_CPP = 2;
constexpr std::uint8_t ENGINE_PROFILE_64 = 1;
constexpr std::uint8_t ENGINE_PROFILE_128 = 2;
constexpr std::uint32_t ENGINE_CPP_BRIDGE_GROUP = 1;
constexpr std::uint32_t ENGINE_CPP_MODEL_PROTOCOL_VERSION = 2;

struct EngineHandshakeResponseV2 { std::uint64_t word0; std::uint64_t word1; };
static_assert(sizeof(EngineHandshakeResponseV2) == 16, "handshake response must be 128 bits");

// Subsequent exchange payload is selected by the handshake response: exactly 8 or 16 bytes.
struct EnginePacket64 { std::uint64_t word; };
struct EnginePacket128 { std::uint64_t word0; std::uint64_t word1; };
static_assert(sizeof(EnginePacket64) == 8, "64-bit packet size mismatch");
static_assert(sizeof(EnginePacket128) == 16, "128-bit packet size mismatch");

#if defined(_WIN32)
#  define ENGINE_MODULE_EXPORT extern "C" __declspec(dllexport)
#else
#  define ENGINE_MODULE_EXPORT extern "C" __attribute__((visibility("default")))
#endif

// Required C++ exports: cpp_model_handshake, cpp_model_protocol_version,
// cpp_model_init, cpp_model_exchange, cpp_model_health, cpp_model_shutdown.
using CppModelHandshakeFn = std::int32_t (*)(std::uint64_t hello, EngineHandshakeResponseV2* response);
using CppModelExchangeFn = std::int32_t (*)(const std::uint8_t* input, std::uint32_t input_size,
                                            std::uint8_t* output, std::uint32_t output_capacity,
                                            std::uint32_t* output_size);
