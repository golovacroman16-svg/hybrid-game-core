#include "shared_memory.h"
#include <array>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <mutex>
namespace {
constexpr uint32_t N=21, M=5, CP=64, LP=32; using Clock=std::chrono::steady_clock;
struct Lease { bool active=false; Clock::time_point deadline{}; };
std::mutex mutex_; std::condition_variable cv;
std::array<EngineSharedValue,N> table{};
std::array<std::array<Lease,M>,2> leases{};
std::array<EngineSharedValue,CP> cpp_pool{};
std::array<std::array<EngineSharedValue,LP>,M> cpp_local{};
const char* names[N]={"simulation_time","delta_time","player_position","player_velocity","input_mask","world_seed","active_scene","physics_tick","frame_index","entity_count","camera_position","camera_direction","gravity","collision_count","audio_state","render_state","asset_generation","game_state","debug_flags","network_tick","user_scalar"};
void prune(){auto now=Clock::now();for(auto& lang:leases)for(auto& l:lang)if(l.active&&now>=l.deadline)l.active=false;}
bool any(uint32_t lang){for(auto& l:leases[lang])if(l.active)return true;return false;}
bool valid(const EngineSharedValue* v){if(!v||v->type<1||v->type>5)return false;if(v->type==5&&!std::memchr(v->text,0,sizeof(v->text)))return false;return true;}
bool owns(uint32_t lang,uint32_t id){return lang<2&&id<M&&leases[lang][id].active&&Clock::now()<leases[lang][id].deadline;}
int32_t set(EngineSharedValue& dst,const EngineSharedValue* v){if(!valid(v))return -2;dst=*v;return 0;}
int32_t get(const EngineSharedValue& src,EngineSharedValue* out){if(!out)return -2;*out=src;return 0;}
}
extern "C" int32_t engine_shared_acquire(uint32_t lang,uint32_t id,uint32_t timeout_ms,uint32_t lease_ms){
 if (lang > 1 || id >= M || lease_ms == 0 || lease_ms > 1000) return -2;
 std::unique_lock<std::mutex> lock(mutex_);
 const auto until = Clock::now() + std::chrono::milliseconds(timeout_ms);
 for (;;) {
  prune();
  if (leases[lang][id].active) return -3;
  if (!any(1U - lang)) {
   leases[lang][id] = {true, Clock::now() + std::chrono::milliseconds(lease_ms)};
   return 0;
  }
  const auto now = Clock::now();
  if (now >= until) return -1;
  // Re-check as soon as the nearest conflicting lease expires, or at caller timeout.
  auto wake_at = until;
  for (const auto& lease : leases[1U - lang]) {
   if (lease.active && lease.deadline < wake_at) wake_at = lease.deadline;
  }
  cv.wait_until(lock, wake_at);
 }
}
extern "C" int32_t engine_shared_release(uint32_t lang,uint32_t id){if(lang>1||id>=M)return -2;std::lock_guard<std::mutex> lock(mutex_);prune();if(!leases[lang][id].active)return -1;leases[lang][id].active=false;cv.notify_all();return 0;}
extern "C" int32_t engine_shared_read(uint32_t lang,uint32_t id,uint32_t slot,EngineSharedValue* out){if(lang>1||id>=M||slot>=N||!out)return -2;std::lock_guard<std::mutex> lock(mutex_);prune();if(!owns(lang,id))return -1;*out=table[slot];return 0;}
extern "C" int32_t engine_shared_write(uint32_t lang,uint32_t id,uint32_t slot,const EngineSharedValue* v){if(lang>1||id>=M||slot>=N||!valid(v))return -2;std::lock_guard<std::mutex> lock(mutex_);prune();if(!owns(lang,id))return -1;table[slot]=*v;return 0;}
extern "C" int32_t engine_shared_update(uint32_t lang,uint32_t id,uint32_t slot,int64_t delta,EngineSharedValue* out){
 if(lang>1||id>=M||slot>=N)return -2;
 std::lock_guard<std::mutex> lock(mutex_);
 prune();
 if(!owns(lang,id))return -1;
 auto& cell=table[slot];
 if(cell.type!=ENGINE_VALUE_EMPTY&&cell.type!=ENGINE_VALUE_I64)return -4;
 const int64_t current=cell.type==ENGINE_VALUE_I64?cell.i64:0;
 if((delta>0&&current>INT64_MAX-delta)||(delta<0&&current<INT64_MIN-delta))return -5;
 EngineSharedValue updated{};
 updated.type=ENGINE_VALUE_I64;
 updated.i64=current+delta;
 cell=updated;
 if(out)*out=cell;
 return 0;
}
extern "C" uint32_t engine_shared_value_size(void){return static_cast<uint32_t>(sizeof(EngineSharedValue));}
extern "C" const char* engine_shared_slot_name(uint32_t slot){return slot<N?names[slot]:nullptr;}
extern "C" uint32_t engine_shared_active_count(uint32_t lang){if(lang>1)return 0;std::lock_guard<std::mutex> lock(mutex_);prune();uint32_t n=0;for(auto& l:leases[lang])if(l.active)++n;return n;}
extern "C" int32_t engine_cpp_pool_set(uint32_t key,const EngineSharedValue* v){if(key>=CP)return -2;std::lock_guard<std::mutex> lock(mutex_);return set(cpp_pool[key],v);}
extern "C" int32_t engine_cpp_pool_get(uint32_t key,EngineSharedValue* out){if(key>=CP)return -2;std::lock_guard<std::mutex> lock(mutex_);return get(cpp_pool[key],out);}
extern "C" int32_t engine_cpp_local_set(uint32_t id,uint32_t key,const EngineSharedValue* v){if(id>=M||key>=LP)return -2;std::lock_guard<std::mutex> lock(mutex_);return set(cpp_local[id][key],v);}
extern "C" int32_t engine_cpp_local_get(uint32_t id,uint32_t key,EngineSharedValue* out){if(id>=M||key>=LP)return -2;std::lock_guard<std::mutex> lock(mutex_);return get(cpp_local[id][key],out);}
