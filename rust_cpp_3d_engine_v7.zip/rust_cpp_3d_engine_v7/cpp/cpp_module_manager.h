#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int32_t cpp_manager_register(const char* name);
uint32_t cpp_manager_count(void);
const char* cpp_manager_name(uint32_t index);
#ifdef __cplusplus
}
#endif
