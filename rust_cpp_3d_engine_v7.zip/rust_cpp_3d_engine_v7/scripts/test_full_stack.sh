#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v cargo >/dev/null 2>&1 || ! command -v rustc >/dev/null 2>&1; then
  echo "ERROR: Rust toolchain missing. Install stable rustc + cargo (see README.md)." >&2
  exit 127
fi
if ! command -v c++ >/dev/null 2>&1; then
  echo "ERROR: C++ compiler missing. Install g++/clang++ and build tools." >&2
  exit 127
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
CXX="${CXX:-c++}"

echo "== Toolchain =="
rustc --version
cargo --version
c++ --version | head -n 1

echo "== Build all example dynamic modules (10 Rust + 11 C++) =="
bash scripts/build_example_plugins.sh

echo "== Rust tests + dynamic module loader + native C++ linkage =="
ENGINE_TEST_PLUGIN_DIR="$ROOT/modules" cargo test --bin rust_cpp_3d_engine -- --nocapture

echo "== Native C++ dynamic-module protocol test =="
"$CXX" -std=c++17 -O2 -Wall -Wextra -Werror tests/native/module_plugin_test.cpp -ldl -o "$TMP_DIR/module_plugin_test"
"$TMP_DIR/module_plugin_test" "$ROOT/modules/cpp"
"$CXX" -std=c++17 -O2 -Wall -Wextra -Werror tests/native/direct_bridge_test.cpp -ldl -o "$TMP_DIR/direct_bridge_test"
"$TMP_DIR/direct_bridge_test" "$ROOT/modules/cpp"

echo "== Cargo executable build =="
cargo build --bin rust_cpp_3d_engine

COMMON_FLAGS=(-std=c++17 -O2 -pthread -Wall -Wextra -Werror -Icpp -Itests/native)

echo "== Native C++ cross-language ABI stress =="
"$CXX" "${COMMON_FLAGS[@]}" tests/native/stress_test.cpp cpp/shared_memory.cpp cpp/module_bridge.cpp -o "$TMP_DIR/stress_test"
"$TMP_DIR/stress_test"

echo "== Native C++ lease deadline test =="
"$CXX" "${COMMON_FLAGS[@]}" tests/native/expiry_wait_test.cpp cpp/shared_memory.cpp -o "$TMP_DIR/expiry_wait_test"
"$TMP_DIR/expiry_wait_test"

echo "== Native C++ atomic update semantics =="
"$CXX" "${COMMON_FLAGS[@]}" tests/native/update_semantics_test.cpp cpp/shared_memory.cpp -o "$TMP_DIR/update_semantics_test"
"$TMP_DIR/update_semantics_test"

echo "FULL STACK TEST SUITE: PASS"
