$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
if (-not (Get-Command rustc -ErrorAction SilentlyContinue)) { throw 'rustc is required' }
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Run this from a Visual Studio Developer PowerShell with cl.exe available' }
New-Item -ItemType Directory -Force -Path 'modules/rust','modules/cpp' | Out-Null
for ($i = 0; $i -le 9; $i++) {
  rustc --edition=2021 --crate-type cdylib --crate-name "rust_model_$i" `
    'plugins/rust/model_template.rs' -o "modules/rust/models $i.dll"
  if ($LASTEXITCODE -ne 0) { throw "Failed to build Rust model $i" }
}
for ($i = 0; $i -le 10; $i++) {
  $Out = Join-Path $Root "modules\cpp\models $i.dll"
  cl.exe /nologo /std:c++17 /EHsc /LD /W4 /WX /I cpp plugins\cpp\model_template.cpp /link /NOLOGO "/OUT:$Out"
  if ($LASTEXITCODE -ne 0) { throw "Failed to build C++ model $i" }
  # MSVC emits an import library and .exp next to the DLL; these are not runtime modules.
}
Write-Host 'Built 10 Rust and 11 C++ DLL modules in .\modules'
