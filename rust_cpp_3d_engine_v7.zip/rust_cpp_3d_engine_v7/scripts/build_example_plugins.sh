#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
command -v rustc >/dev/null 2>&1 || { echo "ERROR: rustc is required to build Rust plug-ins" >&2; exit 2; }
CXX="${CXX:-g++}"
command -v "$CXX" >/dev/null 2>&1 || { echo "ERROR: a C++ compiler (g++/clang++) is required to build C++ plug-ins" >&2; exit 2; }
mkdir -p modules/rust modules/cpp
for i in $(seq 0 9); do
  rustc --edition=2021 --crate-type cdylib --crate-name "rust_model_${i}" \
    plugins/rust/model_template.rs -o "modules/rust/models ${i}.so"
done
for i in $(seq 0 10); do
  "$CXX" -std=c++17 -O2 -Wall -Wextra -Werror -fPIC -shared \
    plugins/cpp/model_template.cpp -o "modules/cpp/models ${i}.so"
done
echo "Built 10 Rust and 11 C++ example modules in ./modules"
