# External module deployment directory

Place C++ modules in `cpp/` and Rust modules in `rust/` using the slot names described in the root README. Windows uses `.dll`; Linux uses `.so`; macOS uses `.dylib`. Missing or invalid modules are replaced by core-owned stubs without shifting slot numbers.
